package controller;

import java.util.ArrayList;
import java.util.List;

/**
 * Holds the cart in memory. It is static so every form (dashboard, cart,
 * checkout) sees the same cart without passing it around.
 */
public class CartManager {
    private static final List<CartItem> ITEMS = new ArrayList<>();

    private CartManager() { }

    public static List<CartItem> getItems() { return ITEMS; }

    public static void addItem(int productId, String name, double price, int qty) {
        for (CartItem item : ITEMS) {
            if (item.getProductId() == productId) {
                item.setQuantity(item.getQuantity() + qty);
                return;
            }
        }
        ITEMS.add(new CartItem(productId, name, price, qty));
    }

    public static void removeItem(int index) {
        if (index >= 0 && index < ITEMS.size()) {
            ITEMS.remove(index);
        }
    }

    /** How many of this product are already in the cart (used for stock checks). */
    public static int getQuantityOf(int productId) {
        for (CartItem item : ITEMS) {
            if (item.getProductId() == productId) {
                return item.getQuantity();
            }
        }
        return 0;
    }

    /** Total number of pieces in the cart. */
    public static int getCount() {
        int count = 0;
        for (CartItem item : ITEMS) {
            count += item.getQuantity();
        }
        return count;
    }

    public static double getTotal() {
        double total = 0;
        for (CartItem item : ITEMS) {
            total += item.getSubtotal();
        }
        return total;
    }

    public static void clear() { ITEMS.clear(); }
}
