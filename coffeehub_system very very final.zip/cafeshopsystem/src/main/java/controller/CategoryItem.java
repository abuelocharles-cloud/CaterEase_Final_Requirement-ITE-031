package controller;

/** A category (id + name) that can be placed inside a JComboBox. */
public class CategoryItem {
    private final int id;
    private final String name;

    public CategoryItem(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public int getId() { return id; }
    public String getName() { return name; }

    /** JComboBox shows whatever toString() returns. */
    @Override
    public String toString() { return name; }
}
