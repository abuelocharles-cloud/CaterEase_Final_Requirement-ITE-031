package view;

import database.database;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import javax.swing.table.DefaultTableModel;

/**
 * Sales report: sales per day and top 10 products, with a date filter.
 * Design this window in the NetBeans Design tab (see SalesReport.form).
 */
public class SalesReport extends javax.swing.JFrame {

    public SalesReport() {
        initComponents();
        Theme.styleField(txtFrom);
        Theme.styleField(txtTo);
        Theme.styleTable(tblDaily);
        Theme.styleTable(tblTop);
        Theme.moneyColumns(tblDaily, 2);
        Theme.moneyColumns(tblTop, 2);
        loadReport();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlRoot = new javax.swing.JPanel();
        pnlHeader = new javax.swing.JPanel();
        lblHeaderTitle = new javax.swing.JLabel();
        lblHeaderSub = new javax.swing.JLabel();
        lblFrom = new javax.swing.JLabel();
        txtFrom = new javax.swing.JTextField();
        lblTo = new javax.swing.JLabel();
        txtTo = new javax.swing.JTextField();
        btnFilter = new view.RoundButton();
        btnShowAll = new view.RoundButton();
        btnClose = new view.RoundButton();
        pnlCard1 = new view.RoundPanel();
        lblCap1 = new javax.swing.JLabel();
        lblTotalSales = new javax.swing.JLabel();
        pnlCard2 = new view.RoundPanel();
        lblCap2 = new javax.swing.JLabel();
        lblOrderCount = new javax.swing.JLabel();
        pnlCard3 = new view.RoundPanel();
        lblCap3 = new javax.swing.JLabel();
        lblAverage = new javax.swing.JLabel();
        pnlDaily = new javax.swing.JPanel();
        lblDaily = new javax.swing.JLabel();
        spDaily = new javax.swing.JScrollPane();
        tblDaily = new javax.swing.JTable();
        pnlTop = new javax.swing.JPanel();
        lblTop = new javax.swing.JLabel();
        spTop = new javax.swing.JScrollPane();
        tblTop = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Sales Reports - Coffee Hub System"); // NOI18N

        pnlRoot.setBackground(new java.awt.Color(245, 236, 224));
        pnlRoot.setPreferredSize(new java.awt.Dimension(1100, 680));
        pnlHeader.setBackground(new java.awt.Color(59, 36, 24));
        lblHeaderTitle.setFont(new java.awt.Font("Georgia", 1, 26)); // NOI18N
        lblHeaderTitle.setForeground(new java.awt.Color(255, 255, 255));
        lblHeaderTitle.setText("Sales Reports"); // NOI18N
        lblHeaderSub.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblHeaderSub.setForeground(new java.awt.Color(215, 190, 165));
        lblHeaderSub.setText("Sales per day and your best-selling products"); // NOI18N
        lblFrom.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblFrom.setForeground(new java.awt.Color(33, 24, 20));
        lblFrom.setText("From (yyyy-mm-dd):"); // NOI18N
        txtFrom.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtFrom.setForeground(new java.awt.Color(33, 24, 20));
        lblTo.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblTo.setForeground(new java.awt.Color(33, 24, 20));
        lblTo.setText("To:"); // NOI18N
        txtTo.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtTo.setForeground(new java.awt.Color(33, 24, 20));
        btnFilter.setBackground(new java.awt.Color(111, 78, 55));
        btnFilter.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnFilter.setForeground(new java.awt.Color(255, 255, 255));
        btnFilter.setText("FILTER"); // NOI18N
        btnFilter.addActionListener(this::btnFilterActionPerformed);
        btnShowAll.setBackground(new java.awt.Color(166, 123, 91));
        btnShowAll.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnShowAll.setForeground(new java.awt.Color(255, 255, 255));
        btnShowAll.setText("SHOW ALL"); // NOI18N
        btnShowAll.addActionListener(this::btnShowAllActionPerformed);
        btnClose.setBackground(new java.awt.Color(59, 36, 24));
        btnClose.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnClose.setForeground(new java.awt.Color(255, 255, 255));
        btnClose.setText("CLOSE"); // NOI18N
        btnClose.addActionListener(this::btnCloseActionPerformed);
        pnlCard1.setBackground(new java.awt.Color(255, 255, 255));
        lblCap1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblCap1.setForeground(new java.awt.Color(166, 123, 91));
        lblCap1.setText("TOTAL SALES"); // NOI18N
        lblTotalSales.setFont(new java.awt.Font("Segoe UI", 1, 26)); // NOI18N
        lblTotalSales.setForeground(new java.awt.Color(59, 36, 24));
        lblTotalSales.setText("\u20B1 0.00"); // NOI18N
        pnlCard2.setBackground(new java.awt.Color(255, 255, 255));
        lblCap2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblCap2.setForeground(new java.awt.Color(166, 123, 91));
        lblCap2.setText("Orders"); // NOI18N
        lblOrderCount.setFont(new java.awt.Font("Segoe UI", 1, 26)); // NOI18N
        lblOrderCount.setForeground(new java.awt.Color(59, 36, 24));
        lblOrderCount.setText("0"); // NOI18N
        pnlCard3.setBackground(new java.awt.Color(255, 255, 255));
        lblCap3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblCap3.setForeground(new java.awt.Color(166, 123, 91));
        lblCap3.setText("Average per order"); // NOI18N
        lblAverage.setFont(new java.awt.Font("Segoe UI", 1, 26)); // NOI18N
        lblAverage.setForeground(new java.awt.Color(59, 36, 24));
        lblAverage.setText("\u20B1 0.00"); // NOI18N
        pnlDaily.setBackground(new java.awt.Color(245, 236, 224));
        lblDaily.setFont(new java.awt.Font("Segoe UI", 1, 17)); // NOI18N
        lblDaily.setForeground(new java.awt.Color(59, 36, 24));
        lblDaily.setText("Sales per Day"); // NOI18N
        tblDaily.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Date", "Orders", "Sales"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        pnlTop.setBackground(new java.awt.Color(245, 236, 224));
        lblTop.setFont(new java.awt.Font("Segoe UI", 1, 17)); // NOI18N
        lblTop.setForeground(new java.awt.Color(59, 36, 24));
        lblTop.setText("Best-Selling Products (Top 10)"); // NOI18N
        tblTop.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Product", "Qty Sold", "Revenue"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        spDaily.setViewportView(tblDaily);
        spTop.setViewportView(tblTop);

        javax.swing.GroupLayout pnlHeaderLayout = new javax.swing.GroupLayout(pnlHeader);
        pnlHeader.setLayout(pnlHeaderLayout);
        pnlHeaderLayout.setHorizontalGroup(
            pnlHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlHeaderLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(lblHeaderTitle, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(28, 28, 28)
            )
            .addGroup(pnlHeaderLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(lblHeaderSub, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(28, 28, 28)
            )
        );
        pnlHeaderLayout.setVerticalGroup(
            pnlHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlHeaderLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(lblHeaderTitle)
                .addGap(2, 2, 2)
                .addComponent(lblHeaderSub)
                .addGap(16, 16, 16)
            )
        );

        javax.swing.GroupLayout pnlCard1Layout = new javax.swing.GroupLayout(pnlCard1);
        pnlCard1.setLayout(pnlCard1Layout);
        pnlCard1Layout.setHorizontalGroup(
            pnlCard1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCard1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(lblCap1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(22, 22, 22)
            )
            .addGroup(pnlCard1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(lblTotalSales, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(22, 22, 22)
            )
        );
        pnlCard1Layout.setVerticalGroup(
            pnlCard1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCard1Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(lblCap1)
                .addGap(4, 4, 4)
                .addComponent(lblTotalSales)
                .addGap(16, 16, 16)
            )
        );

        javax.swing.GroupLayout pnlCard2Layout = new javax.swing.GroupLayout(pnlCard2);
        pnlCard2.setLayout(pnlCard2Layout);
        pnlCard2Layout.setHorizontalGroup(
            pnlCard2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCard2Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(lblCap2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(22, 22, 22)
            )
            .addGroup(pnlCard2Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(lblOrderCount, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(22, 22, 22)
            )
        );
        pnlCard2Layout.setVerticalGroup(
            pnlCard2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCard2Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(lblCap2)
                .addGap(4, 4, 4)
                .addComponent(lblOrderCount)
                .addGap(16, 16, 16)
            )
        );

        javax.swing.GroupLayout pnlCard3Layout = new javax.swing.GroupLayout(pnlCard3);
        pnlCard3.setLayout(pnlCard3Layout);
        pnlCard3Layout.setHorizontalGroup(
            pnlCard3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCard3Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(lblCap3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(22, 22, 22)
            )
            .addGroup(pnlCard3Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(lblAverage, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(22, 22, 22)
            )
        );
        pnlCard3Layout.setVerticalGroup(
            pnlCard3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCard3Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(lblCap3)
                .addGap(4, 4, 4)
                .addComponent(lblAverage)
                .addGap(16, 16, 16)
            )
        );

        javax.swing.GroupLayout pnlDailyLayout = new javax.swing.GroupLayout(pnlDaily);
        pnlDaily.setLayout(pnlDailyLayout);
        pnlDailyLayout.setHorizontalGroup(
            pnlDailyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlDailyLayout.createSequentialGroup()
                .addComponent(lblDaily, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            )
            .addGroup(pnlDailyLayout.createSequentialGroup()
                .addComponent(spDaily, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            )
        );
        pnlDailyLayout.setVerticalGroup(
            pnlDailyLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlDailyLayout.createSequentialGroup()
                .addComponent(lblDaily)
                .addGap(8, 8, 8)
                .addComponent(spDaily, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            )
        );

        javax.swing.GroupLayout pnlTopLayout = new javax.swing.GroupLayout(pnlTop);
        pnlTop.setLayout(pnlTopLayout);
        pnlTopLayout.setHorizontalGroup(
            pnlTopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTopLayout.createSequentialGroup()
                .addComponent(lblTop, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            )
            .addGroup(pnlTopLayout.createSequentialGroup()
                .addComponent(spTop, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            )
        );
        pnlTopLayout.setVerticalGroup(
            pnlTopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlTopLayout.createSequentialGroup()
                .addComponent(lblTop)
                .addGap(8, 8, 8)
                .addComponent(spTop, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            )
        );

        javax.swing.GroupLayout pnlRootLayout = new javax.swing.GroupLayout(pnlRoot);
        pnlRoot.setLayout(pnlRootLayout);
        pnlRootLayout.setHorizontalGroup(
            pnlRootLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlRootLayout.createSequentialGroup()
                .addComponent(pnlHeader, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            )
            .addGroup(pnlRootLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(lblFrom)
                .addGap(8, 8, 8)
                .addComponent(txtFrom, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(lblTo)
                .addGap(8, 8, 8)
                .addComponent(txtTo, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(btnFilter, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(8, 8, 8)
                .addComponent(btnShowAll, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(btnClose, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(8, 8, 8)
                .addGap(14, 14, 14)
            )
            .addGroup(pnlRootLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(pnlCard1, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(pnlCard2, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(pnlCard3, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                .addGap(22, 22, 22)
            )
            .addGroup(pnlRootLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(pnlDaily, javax.swing.GroupLayout.DEFAULT_SIZE, 480, Short.MAX_VALUE)
                .addGap(20, 20, 20)
                .addComponent(pnlTop, javax.swing.GroupLayout.DEFAULT_SIZE, 480, Short.MAX_VALUE)
                .addGap(22, 22, 22)
            )
        );
        pnlRootLayout.setVerticalGroup(
            pnlRootLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlRootLayout.createSequentialGroup()
                .addComponent(pnlHeader)
                .addGap(18, 18, 18)
                .addGroup(pnlRootLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblFrom, javax.swing.GroupLayout.Alignment.CENTER, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtFrom, javax.swing.GroupLayout.Alignment.CENTER, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblTo, javax.swing.GroupLayout.Alignment.CENTER, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtTo, javax.swing.GroupLayout.Alignment.CENTER, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnFilter, javax.swing.GroupLayout.Alignment.CENTER, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnShowAll, javax.swing.GroupLayout.Alignment.CENTER, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnClose, javax.swing.GroupLayout.Alignment.CENTER, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                )
                .addGap(16, 16, 16)
                .addGroup(pnlRootLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pnlCard1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pnlCard2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pnlCard3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                )
                .addGap(16, 16, 16)
                .addGroup(pnlRootLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pnlDaily, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pnlTop, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                )
                .addGap(18, 18, 18)
            )
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnlRoot, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            )
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnlRoot, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            )
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnFilterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFilterActionPerformed
        loadReport();
    }//GEN-LAST:event_btnFilterActionPerformed

    private void btnShowAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnShowAllActionPerformed
        txtFrom.setText("");
        txtTo.setText("");
        loadReport();
    }//GEN-LAST:event_btnShowAllActionPerformed

    private void btnCloseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCloseActionPerformed
        dispose();
    }//GEN-LAST:event_btnCloseActionPerformed

    /** Prepares a query that has two "?" for the From and To dates. */
    private PreparedStatement range(Connection con, String sql, Date from, Date to) throws SQLException {
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setDate(1, from);
        ps.setDate(2, to);
        return ps;
    }

    /** Reloads both report tables and the 3 cards using the date filter. */
    private void loadReport() {
        Date from;
        Date to;
        try {
            from = Date.valueOf(txtFrom.getText().trim().isEmpty() ? "2000-01-01" : txtFrom.getText().trim());
            to = Date.valueOf(txtTo.getText().trim().isEmpty() ? "2999-12-31" : txtTo.getText().trim());
        } catch (IllegalArgumentException ex) {
            Theme.warn(this, "Please type dates like this: 2026-10-08");
            return;
        }

        DefaultTableModel daily = (DefaultTableModel) tblDaily.getModel();
        DefaultTableModel top = (DefaultTableModel) tblTop.getModel();
        daily.setRowCount(0);
        top.setRowCount(0);

        String sqlDaily = "SELECT DATE(order_date) AS sale_date, COUNT(*) AS order_count, SUM(total_amount) AS day_total "
                + "FROM orders WHERE DATE(order_date) BETWEEN ? AND ? "
                + "GROUP BY DATE(order_date) ORDER BY sale_date DESC";
        String sqlTop = "SELECT oi.product_name, SUM(oi.quantity) AS qty, SUM(oi.subtotal) AS revenue "
                + "FROM order_items oi JOIN orders o ON o.id = oi.order_id "
                + "WHERE DATE(o.order_date) BETWEEN ? AND ? "
                + "GROUP BY oi.product_name ORDER BY qty DESC LIMIT 10";

        double totalSales = 0;
        int orderCount = 0;
        try (Connection con = database.getConnection()) {
            try (PreparedStatement ps = range(con, sqlDaily, from, to); ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    daily.addRow(new Object[]{rs.getDate("sale_date").toString(),
                        rs.getInt("order_count"), rs.getDouble("day_total")});
                    totalSales += rs.getDouble("day_total");
                    orderCount += rs.getInt("order_count");
                }
            }
            try (PreparedStatement ps = range(con, sqlTop, from, to); ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    top.addRow(new Object[]{rs.getString("product_name"),
                        rs.getInt("qty"), rs.getDouble("revenue")});
                }
            }
        } catch (SQLException ex) {
            Theme.dbError(this, ex);
            return;
        }
        lblTotalSales.setText(Theme.money(totalSales));
        lblOrderCount.setText(String.valueOf(orderCount));
        lblAverage.setText(Theme.money(orderCount == 0 ? 0 : totalSales / orderCount));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnClose;
    private javax.swing.JButton btnFilter;
    private javax.swing.JButton btnShowAll;
    private javax.swing.JLabel lblAverage;
    private javax.swing.JLabel lblCap1;
    private javax.swing.JLabel lblCap2;
    private javax.swing.JLabel lblCap3;
    private javax.swing.JLabel lblDaily;
    private javax.swing.JLabel lblFrom;
    private javax.swing.JLabel lblHeaderSub;
    private javax.swing.JLabel lblHeaderTitle;
    private javax.swing.JLabel lblOrderCount;
    private javax.swing.JLabel lblTo;
    private javax.swing.JLabel lblTop;
    private javax.swing.JLabel lblTotalSales;
    private javax.swing.JPanel pnlCard1;
    private javax.swing.JPanel pnlCard2;
    private javax.swing.JPanel pnlCard3;
    private javax.swing.JPanel pnlDaily;
    private javax.swing.JPanel pnlHeader;
    private javax.swing.JPanel pnlRoot;
    private javax.swing.JPanel pnlTop;
    private javax.swing.JScrollPane spDaily;
    private javax.swing.JScrollPane spTop;
    private javax.swing.JTable tblDaily;
    private javax.swing.JTable tblTop;
    private javax.swing.JTextField txtFrom;
    private javax.swing.JTextField txtTo;
    // End of variables declaration//GEN-END:variables
}
