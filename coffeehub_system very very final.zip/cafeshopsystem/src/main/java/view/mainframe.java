package view;

import controller.CartManager;

/**
 * Welcome screen for customers: Order Now, Exit. Admin login is hidden (Ctrl+Shift+A or double-click the title).
 * Design this window in the NetBeans Design tab (see mainframe.form).
 */
public class mainframe extends javax.swing.JFrame {

    public mainframe() {
        initComponents();
        // Hidden admin entrance: press Ctrl + Shift + A anywhere on this window
        javax.swing.KeyStroke adminKey = javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_A,
                java.awt.event.InputEvent.CTRL_DOWN_MASK | java.awt.event.InputEvent.SHIFT_DOWN_MASK);
        getRootPane().registerKeyboardAction(e -> openAdminLogin(), adminKey,
                javax.swing.JComponent.WHEN_IN_FOCUSED_WINDOW);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlRoot = new view.BackgroundPanel();
        pnlCard = new view.RoundPanel(40);
        lblTitle = new javax.swing.JLabel();
        lblSubtitle = new javax.swing.JLabel();
        btnordernow = new view.RoundButton();
        btnexit = new view.RoundButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Coffee Hub System"); // NOI18N

        pnlRoot.setPreferredSize(new java.awt.Dimension(900, 600));
        pnlCard.setBackground(new java.awt.Color(255, 255, 255));
        lblTitle.setFont(new java.awt.Font("Georgia", 1, 30)); // NOI18N
        lblTitle.setForeground(new java.awt.Color(59, 36, 24));
        lblTitle.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTitle.setText("COFFEE HUB SYSTEM"); // NOI18N
        lblTitle.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblTitleMouseClicked(evt);
            }
        });
        lblSubtitle.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        lblSubtitle.setForeground(new java.awt.Color(111, 78, 55));
        lblSubtitle.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblSubtitle.setText("Welcome! Please place your order."); // NOI18N
        btnordernow.setBackground(new java.awt.Color(111, 78, 55));
        btnordernow.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        btnordernow.setForeground(new java.awt.Color(255, 255, 255));
        btnordernow.setText("ORDER NOW"); // NOI18N
        btnordernow.addActionListener(this::btnordernowActionPerformed);
        btnexit.setBackground(new java.awt.Color(166, 123, 91));
        btnexit.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        btnexit.setForeground(new java.awt.Color(255, 255, 255));
        btnexit.setText("EXIT"); // NOI18N
        btnexit.addActionListener(this::btnexitActionPerformed);

        javax.swing.GroupLayout pnlCardLayout = new javax.swing.GroupLayout(pnlCard);
        pnlCard.setLayout(pnlCardLayout);
        pnlCardLayout.setHorizontalGroup(
            pnlCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCardLayout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addComponent(lblTitle, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(60, 60, 60)
            )
            .addGroup(pnlCardLayout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addComponent(lblSubtitle, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(60, 60, 60)
            )
            .addGroup(pnlCardLayout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addComponent(btnordernow, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(60, 60, 60)
            )
            .addGroup(pnlCardLayout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addComponent(btnexit, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(60, 60, 60)
            )
        );
        pnlCardLayout.setVerticalGroup(
            pnlCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCardLayout.createSequentialGroup()
                .addGap(56, 56, 56)
                .addComponent(lblTitle)
                .addGap(8, 8, 8)
                .addComponent(lblSubtitle)
                .addGap(36, 36, 36)
                .addComponent(btnordernow, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14)
                .addComponent(btnexit, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(56, 56, 56)
            )
        );

        javax.swing.GroupLayout pnlRootLayout = new javax.swing.GroupLayout(pnlRoot);
        pnlRoot.setLayout(pnlRootLayout);
        pnlRootLayout.setHorizontalGroup(
            pnlRootLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlRootLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(pnlCard, javax.swing.GroupLayout.PREFERRED_SIZE, 580, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE)
            )
        );
        pnlRootLayout.setVerticalGroup(
            pnlRootLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlRootLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(pnlCard)
                .addGap(0, 0, Short.MAX_VALUE)
            )
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnlRoot, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            )
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnlRoot, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            )
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void lblTitleMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblTitleMouseClicked
        if (evt.getClickCount() == 2) {           // double-click on the title
            openAdminLogin();
        }
    }//GEN-LAST:event_lblTitleMouseClicked

    private void btnordernowActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnordernowActionPerformed
        CartManager.clear();                      // every customer starts with an empty cart
        new CustomerDashboard().setVisible(true);
        dispose();
    }//GEN-LAST:event_btnordernowActionPerformed

    private void btnexitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnexitActionPerformed
        System.exit(0);
    }//GEN-LAST:event_btnexitActionPerformed

    /** Opens the admin login window (customers never see a button for it). */
    private void openAdminLogin() {
        new AdminLogin().setVisible(true);
        dispose();
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnexit;
    private javax.swing.JButton btnordernow;
    private javax.swing.JLabel lblSubtitle;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JPanel pnlCard;
    private javax.swing.JPanel pnlRoot;
    // End of variables declaration//GEN-END:variables
}
