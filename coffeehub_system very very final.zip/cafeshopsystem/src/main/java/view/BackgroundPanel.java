package view;

import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.net.URL;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

/**
 * Coffee background. If you add a picture at src/main/resources/images/background.jpg
 * it is used automatically (with a dark brown overlay); otherwise a brown gradient is drawn.
 */
public class BackgroundPanel extends JPanel {

    private final Image picture;

    public BackgroundPanel() {
        URL url = BackgroundPanel.class.getResource("/images/background.jpg");
        picture = (url == null) ? null : new ImageIcon(url).getImage();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        int w = getWidth();
        int h = getHeight();
        if (picture != null) {
            g2.drawImage(picture, 0, 0, w, h, this);
            g2.setColor(new Color(40, 22, 12, 175));
            g2.fillRect(0, 0, w, h);
        } else {
            g2.setPaint(new GradientPaint(0, 0, Theme.DARK, w, h, Theme.BROWN));
            g2.fillRect(0, 0, w, h);
            g2.setColor(new Color(255, 255, 255, 18));
            g2.fillOval(w - 320, -120, 420, 420);
            g2.fillOval(-140, h - 240, 360, 360);
            g2.setColor(new Color(255, 255, 255, 12));
            g2.fillOval(w / 2 - 60, h - 130, 220, 220);
        }
        g2.dispose();
    }
}
