package view;

import database.database;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import javax.swing.table.DefaultTableModel;
import java.sql.Statement;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JOptionPane;
import java.awt.Dimension;

/**
 * Admin orders window: date filter, order list, view items, cancel an order.
 * Design this window in the NetBeans Design tab (see Sales.form).
 */
public class Sales extends javax.swing.JFrame {

    public Sales() {
        initComponents();
        Theme.styleField(txtFrom);
        Theme.styleField(txtTo);
        Theme.styleTable(tblOrders);
        Theme.moneyColumns(tblOrders, 3, 4, 5);
        loadOrders();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlRoot = new javax.swing.JPanel();
        pnlHeader = new javax.swing.JPanel();
        lblHeaderTitle = new javax.swing.JLabel();
        lblHeaderSub = new javax.swing.JLabel();
        lblFrom = new javax.swing.JLabel();
        txtFrom = new javax.swing.JTextField();
        lblTo = new javax.swing.JLabel();
        txtTo = new javax.swing.JTextField();
        btnFilter = new view.RoundButton();
        btnShowAll = new view.RoundButton();
        btnReport = new view.RoundButton();
        btnClose = new view.RoundButton();
        pnlCard1 = new view.RoundPanel();
        lblCap1 = new javax.swing.JLabel();
        lblTotalSales = new javax.swing.JLabel();
        pnlCard2 = new view.RoundPanel();
        lblCap2 = new javax.swing.JLabel();
        lblOrderCount = new javax.swing.JLabel();
        pnlCard3 = new view.RoundPanel();
        lblCap3 = new javax.swing.JLabel();
        lblAverage = new javax.swing.JLabel();
        spOrders = new javax.swing.JScrollPane();
        tblOrders = new javax.swing.JTable();
        btnViewItems = new view.RoundButton();
        btnCancelOrder = new view.RoundButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Sales / Orders - Coffee Hub System"); // NOI18N

        pnlRoot.setBackground(new java.awt.Color(245, 236, 224));
        pnlRoot.setPreferredSize(new java.awt.Dimension(1150, 700));
        pnlHeader.setBackground(new java.awt.Color(59, 36, 24));
        lblHeaderTitle.setFont(new java.awt.Font("Georgia", 1, 26)); // NOI18N
        lblHeaderTitle.setForeground(new java.awt.Color(255, 255, 255));
        lblHeaderTitle.setText("Sales / Orders"); // NOI18N
        lblHeaderSub.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblHeaderSub.setForeground(new java.awt.Color(215, 190, 165));
        lblHeaderSub.setText("Track every order and see how the shop is doing"); // NOI18N
        lblFrom.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblFrom.setForeground(new java.awt.Color(33, 24, 20));
        lblFrom.setText("From (yyyy-mm-dd):"); // NOI18N
        txtFrom.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtFrom.setForeground(new java.awt.Color(33, 24, 20));
        lblTo.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblTo.setForeground(new java.awt.Color(33, 24, 20));
        lblTo.setText("To:"); // NOI18N
        txtTo.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtTo.setForeground(new java.awt.Color(33, 24, 20));
        btnFilter.setBackground(new java.awt.Color(111, 78, 55));
        btnFilter.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnFilter.setForeground(new java.awt.Color(255, 255, 255));
        btnFilter.setText("FILTER"); // NOI18N
        btnFilter.addActionListener(this::btnFilterActionPerformed);
        btnShowAll.setBackground(new java.awt.Color(166, 123, 91));
        btnShowAll.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnShowAll.setForeground(new java.awt.Color(255, 255, 255));
        btnShowAll.setText("SHOW ALL"); // NOI18N
        btnShowAll.addActionListener(this::btnShowAllActionPerformed);
        btnReport.setBackground(new java.awt.Color(59, 36, 24));
        btnReport.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnReport.setForeground(new java.awt.Color(255, 255, 255));
        btnReport.setText("SALES REPORT"); // NOI18N
        btnReport.addActionListener(this::btnReportActionPerformed);
        btnClose.setBackground(new java.awt.Color(59, 36, 24));
        btnClose.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnClose.setForeground(new java.awt.Color(255, 255, 255));
        btnClose.setText("CLOSE"); // NOI18N
        btnClose.addActionListener(this::btnCloseActionPerformed);
        pnlCard1.setBackground(new java.awt.Color(255, 255, 255));
        lblCap1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblCap1.setForeground(new java.awt.Color(166, 123, 91));
        lblCap1.setText("TOTAL SALES"); // NOI18N
        lblTotalSales.setFont(new java.awt.Font("Segoe UI", 1, 26)); // NOI18N
        lblTotalSales.setForeground(new java.awt.Color(59, 36, 24));
        lblTotalSales.setText("\u20B1 0.00"); // NOI18N
        pnlCard2.setBackground(new java.awt.Color(255, 255, 255));
        lblCap2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblCap2.setForeground(new java.awt.Color(166, 123, 91));
        lblCap2.setText("Orders"); // NOI18N
        lblOrderCount.setFont(new java.awt.Font("Segoe UI", 1, 26)); // NOI18N
        lblOrderCount.setForeground(new java.awt.Color(59, 36, 24));
        lblOrderCount.setText("0"); // NOI18N
        pnlCard3.setBackground(new java.awt.Color(255, 255, 255));
        lblCap3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblCap3.setForeground(new java.awt.Color(166, 123, 91));
        lblCap3.setText("Average per order"); // NOI18N
        lblAverage.setFont(new java.awt.Font("Segoe UI", 1, 26)); // NOI18N
        lblAverage.setForeground(new java.awt.Color(59, 36, 24));
        lblAverage.setText("\u20B1 0.00"); // NOI18N
        tblOrders.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Order #", "Date", "Customer", "Total", "Cash", "Change"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        btnViewItems.setBackground(new java.awt.Color(111, 78, 55));
        btnViewItems.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnViewItems.setForeground(new java.awt.Color(255, 255, 255));
        btnViewItems.setText("VIEW ITEMS"); // NOI18N
        btnViewItems.addActionListener(this::btnViewItemsActionPerformed);
        btnCancelOrder.setBackground(new java.awt.Color(160, 60, 50));
        btnCancelOrder.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnCancelOrder.setForeground(new java.awt.Color(255, 255, 255));
        btnCancelOrder.setText("CANCEL ORDER"); // NOI18N
        btnCancelOrder.addActionListener(this::btnCancelOrderActionPerformed);
        spOrders.setViewportView(tblOrders);

        javax.swing.GroupLayout pnlHeaderLayout = new javax.swing.GroupLayout(pnlHeader);
        pnlHeader.setLayout(pnlHeaderLayout);
        pnlHeaderLayout.setHorizontalGroup(
            pnlHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlHeaderLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(lblHeaderTitle, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(28, 28, 28)
            )
            .addGroup(pnlHeaderLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(lblHeaderSub, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(28, 28, 28)
            )
        );
        pnlHeaderLayout.setVerticalGroup(
            pnlHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlHeaderLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(lblHeaderTitle)
                .addGap(2, 2, 2)
                .addComponent(lblHeaderSub)
                .addGap(16, 16, 16)
            )
        );

        javax.swing.GroupLayout pnlCard1Layout = new javax.swing.GroupLayout(pnlCard1);
        pnlCard1.setLayout(pnlCard1Layout);
        pnlCard1Layout.setHorizontalGroup(
            pnlCard1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCard1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(lblCap1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(22, 22, 22)
            )
            .addGroup(pnlCard1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(lblTotalSales, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(22, 22, 22)
            )
        );
        pnlCard1Layout.setVerticalGroup(
            pnlCard1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCard1Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(lblCap1)
                .addGap(4, 4, 4)
                .addComponent(lblTotalSales)
                .addGap(16, 16, 16)
            )
        );

        javax.swing.GroupLayout pnlCard2Layout = new javax.swing.GroupLayout(pnlCard2);
        pnlCard2.setLayout(pnlCard2Layout);
        pnlCard2Layout.setHorizontalGroup(
            pnlCard2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCard2Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(lblCap2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(22, 22, 22)
            )
            .addGroup(pnlCard2Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(lblOrderCount, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(22, 22, 22)
            )
        );
        pnlCard2Layout.setVerticalGroup(
            pnlCard2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCard2Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(lblCap2)
                .addGap(4, 4, 4)
                .addComponent(lblOrderCount)
                .addGap(16, 16, 16)
            )
        );

        javax.swing.GroupLayout pnlCard3Layout = new javax.swing.GroupLayout(pnlCard3);
        pnlCard3.setLayout(pnlCard3Layout);
        pnlCard3Layout.setHorizontalGroup(
            pnlCard3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCard3Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(lblCap3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(22, 22, 22)
            )
            .addGroup(pnlCard3Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(lblAverage, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(22, 22, 22)
            )
        );
        pnlCard3Layout.setVerticalGroup(
            pnlCard3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCard3Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(lblCap3)
                .addGap(4, 4, 4)
                .addComponent(lblAverage)
                .addGap(16, 16, 16)
            )
        );

        javax.swing.GroupLayout pnlRootLayout = new javax.swing.GroupLayout(pnlRoot);
        pnlRoot.setLayout(pnlRootLayout);
        pnlRootLayout.setHorizontalGroup(
            pnlRootLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlRootLayout.createSequentialGroup()
                .addComponent(pnlHeader, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            )
            .addGroup(pnlRootLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(lblFrom)
                .addGap(8, 8, 8)
                .addComponent(txtFrom, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(lblTo)
                .addGap(8, 8, 8)
                .addComponent(txtTo, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(btnFilter, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(8, 8, 8)
                .addComponent(btnShowAll, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(btnReport, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(8, 8, 8)
                .addComponent(btnClose, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(8, 8, 8)
                .addGap(14, 14, 14)
            )
            .addGroup(pnlRootLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(pnlCard1, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(pnlCard2, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(pnlCard3, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                .addGap(22, 22, 22)
            )
            .addGroup(pnlRootLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(spOrders, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(22, 22, 22)
            )
            .addGroup(pnlRootLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(btnViewItems, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(btnCancelOrder, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22)
            )
        );
        pnlRootLayout.setVerticalGroup(
            pnlRootLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlRootLayout.createSequentialGroup()
                .addComponent(pnlHeader)
                .addGap(18, 18, 18)
                .addGroup(pnlRootLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblFrom, javax.swing.GroupLayout.Alignment.CENTER, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtFrom, javax.swing.GroupLayout.Alignment.CENTER, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblTo, javax.swing.GroupLayout.Alignment.CENTER, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtTo, javax.swing.GroupLayout.Alignment.CENTER, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnFilter, javax.swing.GroupLayout.Alignment.CENTER, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnShowAll, javax.swing.GroupLayout.Alignment.CENTER, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnReport, javax.swing.GroupLayout.Alignment.CENTER, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnClose, javax.swing.GroupLayout.Alignment.CENTER, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                )
                .addGap(16, 16, 16)
                .addGroup(pnlRootLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pnlCard1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pnlCard2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pnlCard3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                )
                .addGap(16, 16, 16)
                .addComponent(spOrders, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(12, 12, 12)
                .addGroup(pnlRootLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnViewItems, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCancelOrder, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                )
                .addGap(18, 18, 18)
            )
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnlRoot, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            )
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnlRoot, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            )
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnFilterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFilterActionPerformed
        loadOrders();
    }//GEN-LAST:event_btnFilterActionPerformed

    private void btnShowAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnShowAllActionPerformed
        txtFrom.setText("");
        txtTo.setText("");
        loadOrders();
    }//GEN-LAST:event_btnShowAllActionPerformed

    private void btnReportActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReportActionPerformed
        new SalesReport().setVisible(true);
    }//GEN-LAST:event_btnReportActionPerformed

    private void btnCloseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCloseActionPerformed
        dispose();
    }//GEN-LAST:event_btnCloseActionPerformed

    private void btnViewItemsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewItemsActionPerformed
        int row = tblOrders.getSelectedRow();
        if (row < 0) {
            Theme.warn(this, "Please click an order first.");
            return;
        }
        int orderId = (int) tblOrders.getModel().getValueAt(row, 0);

        DefaultTableModel itemsModel = new DefaultTableModel(
                new Object[][]{}, new String[]{"Product", "Qty", "Price", "Subtotal"}) {
            @Override
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };
        JTable tblItems = new JTable(itemsModel);
        String sql = "SELECT product_name, quantity, price, subtotal FROM order_items WHERE order_id = ? ORDER BY id";
        try (Connection con = database.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, orderId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    itemsModel.addRow(new Object[]{rs.getString("product_name"), rs.getInt("quantity"),
                        rs.getDouble("price"), rs.getDouble("subtotal")});
                }
            }
        } catch (SQLException ex) {
            Theme.dbError(this, ex);
            return;
        }
        JScrollPane sp = new JScrollPane(tblItems);
        Theme.styleTable(tblItems);
        Theme.moneyColumns(tblItems, 2, 3);
        sp.setPreferredSize(new Dimension(560, 220));
        JOptionPane.showMessageDialog(this, sp, "Order #" + orderId, JOptionPane.PLAIN_MESSAGE);
    }//GEN-LAST:event_btnViewItemsActionPerformed

    private void btnCancelOrderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelOrderActionPerformed
        int row = tblOrders.getSelectedRow();
        if (row < 0) {
            Theme.warn(this, "Please click an order first.");
            return;
        }
        int orderId = (int) tblOrders.getModel().getValueAt(row, 0);
        if (!Theme.confirm(this, "Cancel order #" + orderId + "?\nThe items will be returned to stock.")) {
            return;
        }
        String sqlStock = "UPDATE products p JOIN order_items oi ON oi.product_id = p.id "
                + "SET p.stock = p.stock + oi.quantity WHERE oi.order_id = ?";
        try (Connection con = database.getConnection()) {
            con.setAutoCommit(false);
            try (PreparedStatement psStock = con.prepareStatement(sqlStock);
                    PreparedStatement psDelete = con.prepareStatement("DELETE FROM orders WHERE id = ?")) {
                psStock.setInt(1, orderId);
                psStock.executeUpdate();
                psDelete.setInt(1, orderId);        // order_items are deleted automatically (ON DELETE CASCADE)
                psDelete.executeUpdate();
                con.commit();
            } catch (SQLException ex) {
                con.rollback();
                throw ex;
            }
            // MySQL never reuses order numbers by itself. This asks it to continue from the
            // highest order number that still exists (so cancelling the newest order frees its number).
            try (Statement st = con.createStatement()) {
                st.executeUpdate("ALTER TABLE orders AUTO_INCREMENT = 1");
            } catch (SQLException ex) {
                // not important: the numbering simply keeps counting
            }
            loadOrders();
        } catch (SQLException ex) {
            Theme.dbError(this, ex);
        }
    }//GEN-LAST:event_btnCancelOrderActionPerformed

    /** Prepares a query that has two "?" for the From and To dates. */
    private PreparedStatement range(Connection con, String sql, Date from, Date to) throws SQLException {
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setDate(1, from);
        ps.setDate(2, to);
        return ps;
    }

    /** Reloads the orders table and the 3 cards using the date filter. */
    private void loadOrders() {
        Date from;
        Date to;
        try {
            from = Date.valueOf(txtFrom.getText().trim().isEmpty() ? "2000-01-01" : txtFrom.getText().trim());
            to = Date.valueOf(txtTo.getText().trim().isEmpty() ? "2999-12-31" : txtTo.getText().trim());
        } catch (IllegalArgumentException ex) {
            Theme.warn(this, "Please type dates like this: 2026-10-08");
            return;
        }

        DefaultTableModel model = (DefaultTableModel) tblOrders.getModel();
        model.setRowCount(0);
        String sql = "SELECT id, order_date, customer_name, total_amount, cash_amount, change_amount "
                + "FROM orders WHERE DATE(order_date) BETWEEN ? AND ? ORDER BY id DESC";
        double totalSales = 0;
        int orderCount = 0;
        try (Connection con = database.getConnection();
                PreparedStatement ps = range(con, sql, from, to);
                ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                model.addRow(new Object[]{rs.getInt("id"),
                    Theme.dateTime(rs.getTimestamp("order_date")), rs.getString("customer_name"),
                    rs.getDouble("total_amount"), rs.getDouble("cash_amount"),
                    rs.getDouble("change_amount")});
                totalSales += rs.getDouble("total_amount");
                orderCount++;
            }
        } catch (SQLException ex) {
            Theme.dbError(this, ex);
            return;
        }
        lblTotalSales.setText(Theme.money(totalSales));
        lblOrderCount.setText(String.valueOf(orderCount));
        lblAverage.setText(Theme.money(orderCount == 0 ? 0 : totalSales / orderCount));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancelOrder;
    private javax.swing.JButton btnClose;
    private javax.swing.JButton btnFilter;
    private javax.swing.JButton btnReport;
    private javax.swing.JButton btnShowAll;
    private javax.swing.JButton btnViewItems;
    private javax.swing.JLabel lblAverage;
    private javax.swing.JLabel lblCap1;
    private javax.swing.JLabel lblCap2;
    private javax.swing.JLabel lblCap3;
    private javax.swing.JLabel lblFrom;
    private javax.swing.JLabel lblHeaderSub;
    private javax.swing.JLabel lblHeaderTitle;
    private javax.swing.JLabel lblOrderCount;
    private javax.swing.JLabel lblTo;
    private javax.swing.JLabel lblTotalSales;
    private javax.swing.JPanel pnlCard1;
    private javax.swing.JPanel pnlCard2;
    private javax.swing.JPanel pnlCard3;
    private javax.swing.JPanel pnlHeader;
    private javax.swing.JPanel pnlRoot;
    private javax.swing.JScrollPane spOrders;
    private javax.swing.JTable tblOrders;
    private javax.swing.JTextField txtFrom;
    private javax.swing.JTextField txtTo;
    // End of variables declaration//GEN-END:variables
}
