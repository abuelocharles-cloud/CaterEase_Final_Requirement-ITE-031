package view;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.border.EmptyBorder;

/**
 * Rounded button. It uses the button's BACKGROUND color as its fill color,
 * so you simply set "background" in the NetBeans Properties window.
 * (In the Design tab you see a normal button; the rounded look appears when the program runs.)
 * flat = true is used by the admin sidebar: no fill until the mouse is over it.
 */
public class RoundButton extends JButton {

    private final boolean flat;
    private boolean hover;

    public RoundButton() {
        this(false);
    }

    public RoundButton(boolean flat) {
        this.flat = flat;
        setForeground(Color.WHITE);
        setFocusPainted(false);
        setBorderPainted(false);
        setContentAreaFilled(false);
        setOpaque(false);
        setBorder(new EmptyBorder(10, 20, 10, 20));
        setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                hover = true;
                repaint();
            }

            @Override
            public void mouseExited(MouseEvent e) {
                hover = false;
                repaint();
            }
        });
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        Color base = getBackground();
        boolean paintFill = !flat || hover || getModel().isPressed();
        if (paintFill) {
            Color fill = base;
            if (!isEnabled()) {
                fill = new Color(205, 195, 185);
            } else if (getModel().isPressed()) {
                fill = base.darker();
            } else if (hover && !flat) {
                fill = new Color(Math.min(base.getRed() + 25, 255),
                        Math.min(base.getGreen() + 25, 255),
                        Math.min(base.getBlue() + 25, 255));
            }
            g2.setColor(fill);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 18, 18);
        }
        g2.dispose();
        super.paintComponent(g);
    }
}
