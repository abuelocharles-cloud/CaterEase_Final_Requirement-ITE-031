package view;

import controller.CategoryItem;
import database.database;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.table.DefaultTableModel;

/**
 * Products CRUD: Create (ADD), Read (table + search), Update, Delete.
 * Design this window in the NetBeans Design tab (see ManageProducts.form).
 */
public class ManageProducts extends javax.swing.JFrame {

    private int selectedId = -1;

    // values read from the form by validateInput()
    private String inName;
    private double inPrice;
    private int inStock;
    private CategoryItem inCategory;

    public ManageProducts() {
        initComponents();
        Theme.styleField(txtName);
        Theme.styleField(txtPrice);
        Theme.styleField(txtStock);
        Theme.styleField(txtSearch);
        Theme.styleTable(tblProducts);
        Theme.moneyColumns(tblProducts, 3);
        loadCategories();
        loadProducts();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlRoot = new javax.swing.JPanel();
        pnlHeader = new javax.swing.JPanel();
        lblHeaderTitle = new javax.swing.JLabel();
        lblHeaderSub = new javax.swing.JLabel();
        pnlForm = new view.RoundPanel();
        lblName = new javax.swing.JLabel();
        txtName = new javax.swing.JTextField();
        lblCategory = new javax.swing.JLabel();
        cmbCategory = new javax.swing.JComboBox<>();
        lblPrice = new javax.swing.JLabel();
        txtPrice = new javax.swing.JTextField();
        lblStock = new javax.swing.JLabel();
        txtStock = new javax.swing.JTextField();
        btnAdd = new view.RoundButton();
        btnUpdate = new view.RoundButton();
        btnDelete = new view.RoundButton();
        btnClear = new view.RoundButton();
        btnClose = new view.RoundButton();
        pnlRight = new javax.swing.JPanel();
        lblSearch = new javax.swing.JLabel();
        txtSearch = new javax.swing.JTextField();
        spProducts = new javax.swing.JScrollPane();
        tblProducts = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Manage Products - Coffee Hub System"); // NOI18N

        pnlRoot.setBackground(new java.awt.Color(245, 236, 224));
        pnlRoot.setPreferredSize(new java.awt.Dimension(1100, 680));
        pnlHeader.setBackground(new java.awt.Color(59, 36, 24));
        lblHeaderTitle.setFont(new java.awt.Font("Georgia", 1, 26)); // NOI18N
        lblHeaderTitle.setForeground(new java.awt.Color(255, 255, 255));
        lblHeaderTitle.setText("Manage Products"); // NOI18N
        lblHeaderSub.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblHeaderSub.setForeground(new java.awt.Color(215, 190, 165));
        lblHeaderSub.setText("Add, edit and remove the items on your menu"); // NOI18N
        pnlForm.setBackground(new java.awt.Color(255, 255, 255));
        lblName.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblName.setForeground(new java.awt.Color(33, 24, 20));
        lblName.setText("Product Name"); // NOI18N
        txtName.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtName.setForeground(new java.awt.Color(33, 24, 20));
        lblCategory.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblCategory.setForeground(new java.awt.Color(33, 24, 20));
        lblCategory.setText("Category"); // NOI18N
        cmbCategory.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblPrice.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblPrice.setForeground(new java.awt.Color(33, 24, 20));
        lblPrice.setText("Price"); // NOI18N
        txtPrice.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtPrice.setForeground(new java.awt.Color(33, 24, 20));
        lblStock.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblStock.setForeground(new java.awt.Color(33, 24, 20));
        lblStock.setText("Stock (quantity)"); // NOI18N
        txtStock.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtStock.setForeground(new java.awt.Color(33, 24, 20));
        btnAdd.setBackground(new java.awt.Color(111, 78, 55));
        btnAdd.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnAdd.setForeground(new java.awt.Color(255, 255, 255));
        btnAdd.setText("ADD"); // NOI18N
        btnAdd.addActionListener(this::btnAddActionPerformed);
        btnUpdate.setBackground(new java.awt.Color(166, 123, 91));
        btnUpdate.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnUpdate.setForeground(new java.awt.Color(255, 255, 255));
        btnUpdate.setText("UPDATE"); // NOI18N
        btnUpdate.addActionListener(this::btnUpdateActionPerformed);
        btnDelete.setBackground(new java.awt.Color(160, 60, 50));
        btnDelete.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnDelete.setForeground(new java.awt.Color(255, 255, 255));
        btnDelete.setText("DELETE"); // NOI18N
        btnDelete.addActionListener(this::btnDeleteActionPerformed);
        btnClear.setBackground(new java.awt.Color(59, 36, 24));
        btnClear.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnClear.setForeground(new java.awt.Color(255, 255, 255));
        btnClear.setText("CLEAR"); // NOI18N
        btnClear.addActionListener(this::btnClearActionPerformed);
        btnClose.setBackground(new java.awt.Color(59, 36, 24));
        btnClose.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnClose.setForeground(new java.awt.Color(255, 255, 255));
        btnClose.setText("CLOSE"); // NOI18N
        btnClose.addActionListener(this::btnCloseActionPerformed);
        pnlRight.setBackground(new java.awt.Color(245, 236, 224));
        lblSearch.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblSearch.setForeground(new java.awt.Color(33, 24, 20));
        lblSearch.setText("Search product:"); // NOI18N
        txtSearch.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtSearch.setForeground(new java.awt.Color(33, 24, 20));
        txtSearch.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtSearchKeyReleased(evt);
            }
        });
        tblProducts.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Product Name", "Category", "Price", "Stock"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblProducts.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblProductsMouseClicked(evt);
            }
        });
        spProducts.setViewportView(tblProducts);

        javax.swing.GroupLayout pnlHeaderLayout = new javax.swing.GroupLayout(pnlHeader);
        pnlHeader.setLayout(pnlHeaderLayout);
        pnlHeaderLayout.setHorizontalGroup(
            pnlHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlHeaderLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(lblHeaderTitle, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(28, 28, 28)
            )
            .addGroup(pnlHeaderLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(lblHeaderSub, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(28, 28, 28)
            )
        );
        pnlHeaderLayout.setVerticalGroup(
            pnlHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlHeaderLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(lblHeaderTitle)
                .addGap(2, 2, 2)
                .addComponent(lblHeaderSub)
                .addGap(16, 16, 16)
            )
        );

        javax.swing.GroupLayout pnlFormLayout = new javax.swing.GroupLayout(pnlForm);
        pnlForm.setLayout(pnlFormLayout);
        pnlFormLayout.setHorizontalGroup(
            pnlFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlFormLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(lblName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(24, 24, 24)
            )
            .addGroup(pnlFormLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(txtName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(24, 24, 24)
            )
            .addGroup(pnlFormLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(lblCategory, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(24, 24, 24)
            )
            .addGroup(pnlFormLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(cmbCategory, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(24, 24, 24)
            )
            .addGroup(pnlFormLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(lblPrice, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(24, 24, 24)
            )
            .addGroup(pnlFormLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(txtPrice, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(24, 24, 24)
            )
            .addGroup(pnlFormLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(lblStock, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(24, 24, 24)
            )
            .addGroup(pnlFormLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(txtStock, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(24, 24, 24)
            )
            .addGroup(pnlFormLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(btnAdd, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(btnUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24)
            )
            .addGroup(pnlFormLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(btnDelete, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(btnClear, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24)
            )
            .addGroup(pnlFormLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(btnClose, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(24, 24, 24)
            )
        );
        pnlFormLayout.setVerticalGroup(
            pnlFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlFormLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(lblName)
                .addGap(4, 4, 4)
                .addComponent(txtName, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14)
                .addComponent(lblCategory)
                .addGap(4, 4, 4)
                .addComponent(cmbCategory, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14)
                .addComponent(lblPrice)
                .addGap(4, 4, 4)
                .addComponent(txtPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14)
                .addComponent(lblStock)
                .addGap(4, 4, 4)
                .addComponent(txtStock, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24)
                .addGroup(pnlFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnAdd, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnUpdate, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                )
                .addGap(10, 10, 10)
                .addGroup(pnlFormLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnDelete, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnClear, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                )
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(btnClose, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24)
            )
        );

        javax.swing.GroupLayout pnlRightLayout = new javax.swing.GroupLayout(pnlRight);
        pnlRight.setLayout(pnlRightLayout);
        pnlRightLayout.setHorizontalGroup(
            pnlRightLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlRightLayout.createSequentialGroup()
                .addComponent(lblSearch)
                .addGap(10, 10, 10)
                .addComponent(txtSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE)
            )
            .addGroup(pnlRightLayout.createSequentialGroup()
                .addComponent(spProducts, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            )
        );
        pnlRightLayout.setVerticalGroup(
            pnlRightLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlRightLayout.createSequentialGroup()
                .addGroup(pnlRightLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblSearch, javax.swing.GroupLayout.Alignment.CENTER, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtSearch, javax.swing.GroupLayout.Alignment.CENTER, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                )
                .addGap(12, 12, 12)
                .addComponent(spProducts, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            )
        );

        javax.swing.GroupLayout pnlRootLayout = new javax.swing.GroupLayout(pnlRoot);
        pnlRoot.setLayout(pnlRootLayout);
        pnlRootLayout.setHorizontalGroup(
            pnlRootLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlRootLayout.createSequentialGroup()
                .addComponent(pnlHeader, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            )
            .addGroup(pnlRootLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(pnlForm, javax.swing.GroupLayout.PREFERRED_SIZE, 310, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20)
                .addComponent(pnlRight, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(20, 20, 20)
            )
        );
        pnlRootLayout.setVerticalGroup(
            pnlRootLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlRootLayout.createSequentialGroup()
                .addComponent(pnlHeader)
                .addGap(20, 20, 20)
                .addGroup(pnlRootLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pnlForm, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pnlRight, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                )
                .addGap(20, 20, 20)
            )
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnlRoot, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            )
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnlRoot, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            )
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddActionPerformed
        if (!validateInput()) {
            return;
        }
        if (nameExists(inName, -1)) {
            Theme.warn(this, "A product named \"" + inName + "\" already exists.");
            return;
        }
        String sql = "INSERT INTO products (name, category_id, price, stock) VALUES (?, ?, ?, ?)";
        try (Connection con = database.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, inName);
            ps.setInt(2, inCategory.getId());
            ps.setDouble(3, inPrice);
            ps.setInt(4, inStock);
            ps.executeUpdate();
            clearForm();
            loadProducts();
        } catch (SQLException ex) {
            Theme.dbError(this, ex);
        }
    }//GEN-LAST:event_btnAddActionPerformed

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed
        if (selectedId < 0) {
            Theme.warn(this, "Please click a product in the table first.");
            return;
        }
        if (!validateInput()) {
            return;
        }
        if (nameExists(inName, selectedId)) {
            Theme.warn(this, "Another product is already named \"" + inName + "\".");
            return;
        }
        String sql = "UPDATE products SET name = ?, category_id = ?, price = ?, stock = ? WHERE id = ?";
        try (Connection con = database.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, inName);
            ps.setInt(2, inCategory.getId());
            ps.setDouble(3, inPrice);
            ps.setInt(4, inStock);
            ps.setInt(5, selectedId);
            ps.executeUpdate();
            clearForm();
            loadProducts();
        } catch (SQLException ex) {
            Theme.dbError(this, ex);
        }
    }//GEN-LAST:event_btnUpdateActionPerformed

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        if (selectedId < 0) {
            Theme.warn(this, "Please click a product in the table first.");
            return;
        }
        if (!Theme.confirm(this, "Delete \"" + txtName.getText() + "\" from the menu?")) {
            return;
        }
        try (Connection con = database.getConnection();
                PreparedStatement ps = con.prepareStatement("DELETE FROM products WHERE id = ?")) {
            ps.setInt(1, selectedId);
            ps.executeUpdate();
            clearForm();
            loadProducts();
        } catch (SQLException ex) {
            Theme.dbError(this, ex);
        }
    }//GEN-LAST:event_btnDeleteActionPerformed

    private void btnClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearActionPerformed
        clearForm();
    }//GEN-LAST:event_btnClearActionPerformed

    private void btnCloseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCloseActionPerformed
        dispose();
    }//GEN-LAST:event_btnCloseActionPerformed

    private void txtSearchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtSearchKeyReleased
        loadProducts();
    }//GEN-LAST:event_txtSearchKeyReleased

    private void tblProductsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblProductsMouseClicked
        int row = tblProducts.getSelectedRow();
        if (row < 0) {
            return;
        }
        DefaultTableModel model = (DefaultTableModel) tblProducts.getModel();
        selectedId = (int) model.getValueAt(row, 0);
        txtName.setText(String.valueOf(model.getValueAt(row, 1)));
        String categoryName = String.valueOf(model.getValueAt(row, 2));
        for (int i = 0; i < cmbCategory.getItemCount(); i++) {
            if (cmbCategory.getItemAt(i).getName().equals(categoryName)) {
                cmbCategory.setSelectedIndex(i);
                break;
            }
        }
        txtPrice.setText(String.format("%.2f", ((Number) model.getValueAt(row, 3)).doubleValue()));
        txtStock.setText(String.valueOf(model.getValueAt(row, 4)));
    }//GEN-LAST:event_tblProductsMouseClicked

    private void loadCategories() {
        cmbCategory.removeAllItems();
        try (Connection con = database.getConnection();
                Statement st = con.createStatement();
                ResultSet rs = st.executeQuery("SELECT id, name FROM categories ORDER BY name")) {
            while (rs.next()) {
                cmbCategory.addItem(new CategoryItem(rs.getInt("id"), rs.getString("name")));
            }
        } catch (SQLException ex) {
            Theme.dbError(this, ex);
        }
    }

    private void loadProducts() {
        DefaultTableModel model = (DefaultTableModel) tblProducts.getModel();
        model.setRowCount(0);
        String sql = "SELECT p.id, p.name, c.name AS category, p.price, p.stock "
                + "FROM products p JOIN categories c ON c.id = p.category_id "
                + "WHERE p.name LIKE ? ORDER BY p.id";
        try (Connection con = database.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, "%" + txtSearch.getText().trim() + "%");
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    model.addRow(new Object[]{rs.getInt("id"), rs.getString("name"),
                        rs.getString("category"), rs.getDouble("price"), rs.getInt("stock")});
                }
            }
        } catch (SQLException ex) {
            Theme.dbError(this, ex);
        }
    }

    /** True if another product (not excludeId) already has this name. Stops duplicates like two "Cappuccino". */
    private boolean nameExists(String name, int excludeId) {
        String sql = "SELECT COUNT(*) FROM products WHERE LOWER(name) = LOWER(?) AND id <> ?";
        try (Connection con = database.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, name);
            ps.setInt(2, excludeId);
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                return rs.getInt(1) > 0;
            }
        } catch (SQLException ex) {
            Theme.dbError(this, ex);
            return true;      // on error, do not save
        }
    }

    /** Checks the form. Returns false (and shows a message) if something is wrong. */
    private boolean validateInput() {
        inName = txtName.getText().trim();
        inCategory = (CategoryItem) cmbCategory.getSelectedItem();
        if (inName.isEmpty()) {
            Theme.warn(this, "Please enter the product name.");
            return false;
        }
        if (inCategory == null) {
            Theme.warn(this, "Please add a category first (Manage Categories).");
            return false;
        }
        try {
            inPrice = Double.parseDouble(txtPrice.getText().trim());
            if (inPrice < 0) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException ex) {
            Theme.warn(this, "Price must be a number, for example 120 or 120.50.");
            return false;
        }
        try {
            inStock = Integer.parseInt(txtStock.getText().trim());
            if (inStock < 0) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException ex) {
            Theme.warn(this, "Stock must be a whole number, for example 25.");
            return false;
        }
        return true;
    }

    private void clearForm() {
        selectedId = -1;
        txtName.setText("");
        txtPrice.setText("");
        txtStock.setText("");
        if (cmbCategory.getItemCount() > 0) {
            cmbCategory.setSelectedIndex(0);
        }
        tblProducts.clearSelection();
        txtName.requestFocus();
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAdd;
    private javax.swing.JButton btnClear;
    private javax.swing.JButton btnClose;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnUpdate;
    private javax.swing.JComboBox<controller.CategoryItem> cmbCategory;
    private javax.swing.JLabel lblCategory;
    private javax.swing.JLabel lblHeaderSub;
    private javax.swing.JLabel lblHeaderTitle;
    private javax.swing.JLabel lblName;
    private javax.swing.JLabel lblPrice;
    private javax.swing.JLabel lblSearch;
    private javax.swing.JLabel lblStock;
    private javax.swing.JPanel pnlForm;
    private javax.swing.JPanel pnlHeader;
    private javax.swing.JPanel pnlRight;
    private javax.swing.JPanel pnlRoot;
    private javax.swing.JScrollPane spProducts;
    private javax.swing.JTable tblProducts;
    private javax.swing.JTextField txtName;
    private javax.swing.JTextField txtPrice;
    private javax.swing.JTextField txtSearch;
    private javax.swing.JTextField txtStock;
    // End of variables declaration//GEN-END:variables
}
