package view;

import database.database;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Admin login. Checks the admins table (password is stored as a SHA-256 hash).
 * Design this window in the NetBeans Design tab (see AdminLogin.form).
 */
public class AdminLogin extends javax.swing.JFrame {

    private int failedAttempts = 0;   // wrong passwords in a row

    public AdminLogin() {
        initComponents();
        Theme.styleField(txtUserName);
        Theme.styleField(txtPassWord);
        getRootPane().setDefaultButton(btnLogin);   // pressing Enter = LOGIN
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlRoot = new view.BackgroundPanel();
        pnlCard = new view.RoundPanel(40);
        lblTitle = new javax.swing.JLabel();
        lblUser = new javax.swing.JLabel();
        txtUserName = new javax.swing.JTextField();
        lblPass = new javax.swing.JLabel();
        txtPassWord = new javax.swing.JPasswordField();
        btnLogin = new view.RoundButton();
        btnBack = new view.RoundButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Admin Login - Coffee Hub System"); // NOI18N

        pnlRoot.setPreferredSize(new java.awt.Dimension(900, 600));
        pnlCard.setBackground(new java.awt.Color(255, 255, 255));
        lblTitle.setFont(new java.awt.Font("Georgia", 1, 28)); // NOI18N
        lblTitle.setForeground(new java.awt.Color(59, 36, 24));
        lblTitle.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTitle.setText("ADMIN LOGIN"); // NOI18N
        lblUser.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblUser.setForeground(new java.awt.Color(33, 24, 20));
        lblUser.setText("Username"); // NOI18N
        txtUserName.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtUserName.setForeground(new java.awt.Color(33, 24, 20));
        lblPass.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblPass.setForeground(new java.awt.Color(33, 24, 20));
        lblPass.setText("Password"); // NOI18N
        txtPassWord.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtPassWord.setForeground(new java.awt.Color(33, 24, 20));
        btnLogin.setBackground(new java.awt.Color(111, 78, 55));
        btnLogin.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        btnLogin.setForeground(new java.awt.Color(255, 255, 255));
        btnLogin.setText("LOGIN"); // NOI18N
        btnLogin.addActionListener(this::btnLoginActionPerformed);
        btnBack.setBackground(new java.awt.Color(166, 123, 91));
        btnBack.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnBack.setForeground(new java.awt.Color(255, 255, 255));
        btnBack.setText("BACK"); // NOI18N
        btnBack.addActionListener(this::btnBackActionPerformed);

        javax.swing.GroupLayout pnlCardLayout = new javax.swing.GroupLayout(pnlCard);
        pnlCard.setLayout(pnlCardLayout);
        pnlCardLayout.setHorizontalGroup(
            pnlCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCardLayout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addComponent(lblTitle, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(50, 50, 50)
            )
            .addGroup(pnlCardLayout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addComponent(lblUser, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(50, 50, 50)
            )
            .addGroup(pnlCardLayout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addComponent(txtUserName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(50, 50, 50)
            )
            .addGroup(pnlCardLayout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addComponent(lblPass, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(50, 50, 50)
            )
            .addGroup(pnlCardLayout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addComponent(txtPassWord, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(50, 50, 50)
            )
            .addGroup(pnlCardLayout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addComponent(btnLogin, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(50, 50, 50)
            )
            .addGroup(pnlCardLayout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addComponent(btnBack, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(50, 50, 50)
            )
        );
        pnlCardLayout.setVerticalGroup(
            pnlCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCardLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(lblTitle)
                .addGap(22, 22, 22)
                .addComponent(lblUser)
                .addGap(4, 4, 4)
                .addComponent(txtUserName, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(lblPass)
                .addGap(4, 4, 4)
                .addComponent(txtPassWord, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22)
                .addComponent(btnLogin, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(8, 8, 8)
                .addComponent(btnBack, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34)
            )
        );

        javax.swing.GroupLayout pnlRootLayout = new javax.swing.GroupLayout(pnlRoot);
        pnlRoot.setLayout(pnlRootLayout);
        pnlRootLayout.setHorizontalGroup(
            pnlRootLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlRootLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(pnlCard, javax.swing.GroupLayout.PREFERRED_SIZE, 460, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE)
            )
        );
        pnlRootLayout.setVerticalGroup(
            pnlRootLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlRootLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(pnlCard)
                .addGap(0, 0, Short.MAX_VALUE)
            )
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnlRoot, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            )
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnlRoot, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            )
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLoginActionPerformed
        String username = txtUserName.getText().trim();
        String password = new String(txtPassWord.getPassword());

        if (username.isEmpty() || password.isEmpty()) {
            Theme.warn(this, "Please enter your username and password.");
            return;
        }

        String sql = "SELECT full_name FROM admins WHERE username = ? AND password = SHA2(?, 256)";
        try (Connection con = database.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, username);
            ps.setString(2, password);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    new AdminDashboard(rs.getString("full_name")).setVisible(true);
                    dispose();
                } else {
                    failedAttempts++;
                    txtPassWord.setText("");
                    if (failedAttempts >= 3) {
                        Theme.warn(this, "Too many wrong attempts.\nPlease wait 30 seconds.");
                        lockOut();
                    } else {
                        Theme.warn(this, "Wrong username or password.\nAttempts left: " + (3 - failedAttempts));
                    }
                }
            }
        } catch (SQLException ex) {
            Theme.dbError(this, ex);
        }
    }//GEN-LAST:event_btnLoginActionPerformed

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        new mainframe().setVisible(true);
        dispose();
    }//GEN-LAST:event_btnBackActionPerformed

    /** After 3 wrong passwords the login is locked for 30 seconds. */
    private void lockOut() {
        failedAttempts = 0;
        txtUserName.setEnabled(false);
        txtPassWord.setEnabled(false);
        btnLogin.setEnabled(false);
        final int[] seconds = {30};
        btnLogin.setText("LOCKED (" + seconds[0] + "s)");
        javax.swing.Timer timer = new javax.swing.Timer(1000, null);
        timer.addActionListener(e -> {
            seconds[0]--;
            if (seconds[0] <= 0) {
                timer.stop();
                txtUserName.setEnabled(true);
                txtPassWord.setEnabled(true);
                btnLogin.setEnabled(true);
                btnLogin.setText("LOGIN");
            } else {
                btnLogin.setText("LOCKED (" + seconds[0] + "s)");
            }
        });
        timer.start();
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnLogin;
    private javax.swing.JLabel lblPass;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JLabel lblUser;
    private javax.swing.JPanel pnlCard;
    private javax.swing.JPanel pnlRoot;
    private javax.swing.JPasswordField txtPassWord;
    private javax.swing.JTextField txtUserName;
    // End of variables declaration//GEN-END:variables
}
