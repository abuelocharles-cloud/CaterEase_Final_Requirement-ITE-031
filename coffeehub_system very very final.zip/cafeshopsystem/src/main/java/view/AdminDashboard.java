package view;

import database.database;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JFrame;
import javax.swing.table.DefaultTableModel;

/**
 * Admin home: sidebar menu, 4 summary cards and the latest orders.
 * Design this window in the NetBeans Design tab (see AdminDashboard.form).
 */
public class AdminDashboard extends javax.swing.JFrame {

    public AdminDashboard(String adminName) {
        initComponents();
        lblWelcome.setText("Welcome back, " + adminName + "!");
        lblDate.setText(new SimpleDateFormat("EEEE, MMMM dd, yyyy").format(new Date()));
        Theme.styleTable(tblRecent);
        Theme.moneyColumns(tblRecent, 3);
        loadStats();
    }

    public AdminDashboard() {
        this("Administrator");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlRoot = new javax.swing.JPanel();
        pnlSidebar = new javax.swing.JPanel();
        lblLogo = new javax.swing.JLabel();
        lblSidebarSub = new javax.swing.JLabel();
        btnDashboard = new view.RoundButton(true);
        btnManagementProduct = new view.RoundButton(true);
        btnManageCategory = new view.RoundButton(true);
        btnSalesOrder = new view.RoundButton(true);
        btnReports = new view.RoundButton(true);
        btnLogout = new view.RoundButton(true);
        pnlContent = new javax.swing.JPanel();
        lblWelcome = new javax.swing.JLabel();
        lblDate = new javax.swing.JLabel();
        pnlCard1 = new view.RoundPanel();
        lblCap1 = new javax.swing.JLabel();
        lblProducts = new javax.swing.JLabel();
        pnlCard2 = new view.RoundPanel();
        lblCap2 = new javax.swing.JLabel();
        lblCategories = new javax.swing.JLabel();
        pnlCard3 = new view.RoundPanel();
        lblCap3 = new javax.swing.JLabel();
        lblOrders = new javax.swing.JLabel();
        pnlCard4 = new view.RoundPanel();
        lblCap4 = new javax.swing.JLabel();
        lblSales = new javax.swing.JLabel();
        lblRecent = new javax.swing.JLabel();
        btnRefresh = new view.RoundButton();
        spRecent = new javax.swing.JScrollPane();
        tblRecent = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Admin Dashboard - Coffee Hub System"); // NOI18N

        pnlRoot.setBackground(new java.awt.Color(245, 236, 224));
        pnlRoot.setPreferredSize(new java.awt.Dimension(1200, 720));
        pnlSidebar.setBackground(new java.awt.Color(59, 36, 24));
        lblLogo.setFont(new java.awt.Font("Georgia", 1, 22)); // NOI18N
        lblLogo.setForeground(new java.awt.Color(255, 255, 255));
        lblLogo.setText("COFFEE HUB"); // NOI18N
        lblSidebarSub.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblSidebarSub.setForeground(new java.awt.Color(166, 123, 91));
        lblSidebarSub.setText("Admin Panel"); // NOI18N
        btnDashboard.setBackground(new java.awt.Color(111, 78, 55));
        btnDashboard.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        btnDashboard.setForeground(new java.awt.Color(245, 236, 224));
        btnDashboard.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnDashboard.setText("Dashboard"); // NOI18N
        btnDashboard.addActionListener(this::btnDashboardActionPerformed);
        btnManagementProduct.setBackground(new java.awt.Color(111, 78, 55));
        btnManagementProduct.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        btnManagementProduct.setForeground(new java.awt.Color(245, 236, 224));
        btnManagementProduct.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnManagementProduct.setText("Manage Products"); // NOI18N
        btnManagementProduct.addActionListener(this::btnManagementProductActionPerformed);
        btnManageCategory.setBackground(new java.awt.Color(111, 78, 55));
        btnManageCategory.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        btnManageCategory.setForeground(new java.awt.Color(245, 236, 224));
        btnManageCategory.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnManageCategory.setText("Manage Categories"); // NOI18N
        btnManageCategory.addActionListener(this::btnManageCategoryActionPerformed);
        btnSalesOrder.setBackground(new java.awt.Color(111, 78, 55));
        btnSalesOrder.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        btnSalesOrder.setForeground(new java.awt.Color(245, 236, 224));
        btnSalesOrder.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnSalesOrder.setText("Sales / Orders"); // NOI18N
        btnSalesOrder.addActionListener(this::btnSalesOrderActionPerformed);
        btnReports.setBackground(new java.awt.Color(111, 78, 55));
        btnReports.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        btnReports.setForeground(new java.awt.Color(245, 236, 224));
        btnReports.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnReports.setText("Sales Reports"); // NOI18N
        btnReports.addActionListener(this::btnReportsActionPerformed);
        btnLogout.setBackground(new java.awt.Color(111, 78, 55));
        btnLogout.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        btnLogout.setForeground(new java.awt.Color(245, 236, 224));
        btnLogout.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnLogout.setText("Logout"); // NOI18N
        btnLogout.addActionListener(this::btnLogoutActionPerformed);
        pnlContent.setBackground(new java.awt.Color(245, 236, 224));
        lblWelcome.setFont(new java.awt.Font("Georgia", 1, 28)); // NOI18N
        lblWelcome.setForeground(new java.awt.Color(59, 36, 24));
        lblWelcome.setText("Welcome back, Administrator!"); // NOI18N
        lblDate.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblDate.setForeground(new java.awt.Color(111, 78, 55));
        lblDate.setText("Today"); // NOI18N
        pnlCard1.setBackground(new java.awt.Color(255, 255, 255));
        lblCap1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblCap1.setForeground(new java.awt.Color(166, 123, 91));
        lblCap1.setText("Total Products"); // NOI18N
        lblProducts.setFont(new java.awt.Font("Segoe UI", 1, 26)); // NOI18N
        lblProducts.setForeground(new java.awt.Color(59, 36, 24));
        lblProducts.setText("0"); // NOI18N
        pnlCard2.setBackground(new java.awt.Color(255, 255, 255));
        lblCap2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblCap2.setForeground(new java.awt.Color(166, 123, 91));
        lblCap2.setText("Total Categories"); // NOI18N
        lblCategories.setFont(new java.awt.Font("Segoe UI", 1, 26)); // NOI18N
        lblCategories.setForeground(new java.awt.Color(59, 36, 24));
        lblCategories.setText("0"); // NOI18N
        pnlCard3.setBackground(new java.awt.Color(255, 255, 255));
        lblCap3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblCap3.setForeground(new java.awt.Color(166, 123, 91));
        lblCap3.setText("Total Orders"); // NOI18N
        lblOrders.setFont(new java.awt.Font("Segoe UI", 1, 26)); // NOI18N
        lblOrders.setForeground(new java.awt.Color(59, 36, 24));
        lblOrders.setText("0"); // NOI18N
        pnlCard4.setBackground(new java.awt.Color(255, 255, 255));
        lblCap4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblCap4.setForeground(new java.awt.Color(166, 123, 91));
        lblCap4.setText("Total Sales"); // NOI18N
        lblSales.setFont(new java.awt.Font("Segoe UI", 1, 26)); // NOI18N
        lblSales.setForeground(new java.awt.Color(59, 36, 24));
        lblSales.setText("\u20B1 0.00"); // NOI18N
        lblRecent.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblRecent.setForeground(new java.awt.Color(59, 36, 24));
        lblRecent.setText("Recent Orders"); // NOI18N
        btnRefresh.setBackground(new java.awt.Color(111, 78, 55));
        btnRefresh.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnRefresh.setForeground(new java.awt.Color(255, 255, 255));
        btnRefresh.setText("REFRESH"); // NOI18N
        btnRefresh.addActionListener(this::btnRefreshActionPerformed);
        tblRecent.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Order #", "Date", "Customer", "Total"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        spRecent.setViewportView(tblRecent);

        javax.swing.GroupLayout pnlSidebarLayout = new javax.swing.GroupLayout(pnlSidebar);
        pnlSidebar.setLayout(pnlSidebarLayout);
        pnlSidebarLayout.setHorizontalGroup(
            pnlSidebarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlSidebarLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(lblLogo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(16, 16, 16)
            )
            .addGroup(pnlSidebarLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(lblSidebarSub, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(16, 16, 16)
            )
            .addGroup(pnlSidebarLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(btnDashboard, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(16, 16, 16)
            )
            .addGroup(pnlSidebarLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(btnManagementProduct, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(16, 16, 16)
            )
            .addGroup(pnlSidebarLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(btnManageCategory, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(16, 16, 16)
            )
            .addGroup(pnlSidebarLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(btnSalesOrder, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(16, 16, 16)
            )
            .addGroup(pnlSidebarLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(btnReports, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(16, 16, 16)
            )
            .addGroup(pnlSidebarLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(btnLogout, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(16, 16, 16)
            )
        );
        pnlSidebarLayout.setVerticalGroup(
            pnlSidebarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlSidebarLayout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(lblLogo)
                .addComponent(lblSidebarSub)
                .addGap(34, 34, 34)
                .addComponent(btnDashboard, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(6, 6, 6)
                .addComponent(btnManagementProduct, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(6, 6, 6)
                .addComponent(btnManageCategory, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(6, 6, 6)
                .addComponent(btnSalesOrder, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(6, 6, 6)
                .addComponent(btnReports, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(btnLogout, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20)
            )
        );

        javax.swing.GroupLayout pnlCard1Layout = new javax.swing.GroupLayout(pnlCard1);
        pnlCard1.setLayout(pnlCard1Layout);
        pnlCard1Layout.setHorizontalGroup(
            pnlCard1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCard1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(lblCap1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(22, 22, 22)
            )
            .addGroup(pnlCard1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(lblProducts, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(22, 22, 22)
            )
        );
        pnlCard1Layout.setVerticalGroup(
            pnlCard1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCard1Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(lblCap1)
                .addGap(4, 4, 4)
                .addComponent(lblProducts)
                .addGap(16, 16, 16)
            )
        );

        javax.swing.GroupLayout pnlCard2Layout = new javax.swing.GroupLayout(pnlCard2);
        pnlCard2.setLayout(pnlCard2Layout);
        pnlCard2Layout.setHorizontalGroup(
            pnlCard2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCard2Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(lblCap2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(22, 22, 22)
            )
            .addGroup(pnlCard2Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(lblCategories, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(22, 22, 22)
            )
        );
        pnlCard2Layout.setVerticalGroup(
            pnlCard2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCard2Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(lblCap2)
                .addGap(4, 4, 4)
                .addComponent(lblCategories)
                .addGap(16, 16, 16)
            )
        );

        javax.swing.GroupLayout pnlCard3Layout = new javax.swing.GroupLayout(pnlCard3);
        pnlCard3.setLayout(pnlCard3Layout);
        pnlCard3Layout.setHorizontalGroup(
            pnlCard3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCard3Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(lblCap3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(22, 22, 22)
            )
            .addGroup(pnlCard3Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(lblOrders, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(22, 22, 22)
            )
        );
        pnlCard3Layout.setVerticalGroup(
            pnlCard3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCard3Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(lblCap3)
                .addGap(4, 4, 4)
                .addComponent(lblOrders)
                .addGap(16, 16, 16)
            )
        );

        javax.swing.GroupLayout pnlCard4Layout = new javax.swing.GroupLayout(pnlCard4);
        pnlCard4.setLayout(pnlCard4Layout);
        pnlCard4Layout.setHorizontalGroup(
            pnlCard4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCard4Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(lblCap4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(22, 22, 22)
            )
            .addGroup(pnlCard4Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(lblSales, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(22, 22, 22)
            )
        );
        pnlCard4Layout.setVerticalGroup(
            pnlCard4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlCard4Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(lblCap4)
                .addGap(4, 4, 4)
                .addComponent(lblSales)
                .addGap(16, 16, 16)
            )
        );

        javax.swing.GroupLayout pnlContentLayout = new javax.swing.GroupLayout(pnlContent);
        pnlContent.setLayout(pnlContentLayout);
        pnlContentLayout.setHorizontalGroup(
            pnlContentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlContentLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(lblWelcome, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(30, 30, 30)
            )
            .addGroup(pnlContentLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(lblDate, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(30, 30, 30)
            )
            .addGroup(pnlContentLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(pnlCard1, javax.swing.GroupLayout.DEFAULT_SIZE, 190, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(pnlCard2, javax.swing.GroupLayout.DEFAULT_SIZE, 190, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(pnlCard3, javax.swing.GroupLayout.DEFAULT_SIZE, 190, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(pnlCard4, javax.swing.GroupLayout.DEFAULT_SIZE, 190, Short.MAX_VALUE)
                .addGap(30, 30, 30)
            )
            .addGroup(pnlContentLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(lblRecent)
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(btnRefresh, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
            )
            .addGroup(pnlContentLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(spRecent, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(30, 30, 30)
            )
        );
        pnlContentLayout.setVerticalGroup(
            pnlContentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlContentLayout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(lblWelcome)
                .addComponent(lblDate)
                .addGap(20, 20, 20)
                .addGroup(pnlContentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pnlCard1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pnlCard2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pnlCard3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pnlCard4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                )
                .addGap(22, 22, 22)
                .addGroup(pnlContentLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblRecent, javax.swing.GroupLayout.Alignment.CENTER, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnRefresh, javax.swing.GroupLayout.Alignment.CENTER, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                )
                .addGap(10, 10, 10)
                .addComponent(spRecent, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(26, 26, 26)
            )
        );

        javax.swing.GroupLayout pnlRootLayout = new javax.swing.GroupLayout(pnlRoot);
        pnlRoot.setLayout(pnlRootLayout);
        pnlRootLayout.setHorizontalGroup(
            pnlRootLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlRootLayout.createSequentialGroup()
                .addComponent(pnlSidebar, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(pnlContent, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            )
        );
        pnlRootLayout.setVerticalGroup(
            pnlRootLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlRootLayout.createSequentialGroup()
                .addGroup(pnlRootLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pnlSidebar, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pnlContent, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                )
            )
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnlRoot, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            )
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnlRoot, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            )
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnDashboardActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDashboardActionPerformed
        loadStats();
    }//GEN-LAST:event_btnDashboardActionPerformed

    private void btnManagementProductActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnManagementProductActionPerformed
        open(new ManageProducts());
    }//GEN-LAST:event_btnManagementProductActionPerformed

    private void btnManageCategoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnManageCategoryActionPerformed
        open(new ManageCategories());
    }//GEN-LAST:event_btnManageCategoryActionPerformed

    private void btnSalesOrderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalesOrderActionPerformed
        open(new Sales());
    }//GEN-LAST:event_btnSalesOrderActionPerformed

    private void btnReportsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReportsActionPerformed
        open(new SalesReport());
    }//GEN-LAST:event_btnReportsActionPerformed

    private void btnLogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLogoutActionPerformed
        if (Theme.confirm(this, "Do you want to log out?")) {
            new mainframe().setVisible(true);
            dispose();
        }
    }//GEN-LAST:event_btnLogoutActionPerformed

    private void btnRefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRefreshActionPerformed
        loadStats();
    }//GEN-LAST:event_btnRefreshActionPerformed

    /** Opens a window and refreshes the cards when that window is closed. */
    private void open(JFrame window) {
        window.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent e) {
                loadStats();
            }
        });
        window.setVisible(true);
    }

    private void loadStats() {
        DefaultTableModel model = (DefaultTableModel) tblRecent.getModel();
        try (Connection con = database.getConnection(); Statement st = con.createStatement()) {
            lblProducts.setText(String.valueOf((int) scalar(st, "SELECT COUNT(*) FROM products")));
            lblCategories.setText(String.valueOf((int) scalar(st, "SELECT COUNT(*) FROM categories")));
            lblOrders.setText(String.valueOf((int) scalar(st, "SELECT COUNT(*) FROM orders")));
            lblSales.setText(Theme.money(scalar(st, "SELECT COALESCE(SUM(total_amount), 0) FROM orders")));

            model.setRowCount(0);
            String sql = "SELECT id, order_date, customer_name, total_amount "
                    + "FROM orders ORDER BY id DESC LIMIT 10";
            try (ResultSet rs = st.executeQuery(sql)) {
                while (rs.next()) {
                    model.addRow(new Object[]{
                        rs.getInt("id"),
                        Theme.dateTime(rs.getTimestamp("order_date")),
                        rs.getString("customer_name"),
                        rs.getDouble("total_amount")});
                }
            }
        } catch (SQLException ex) {
            Theme.dbError(this, ex);
        }
    }

    /** Runs a query that returns one number. */
    private double scalar(Statement st, String sql) throws SQLException {
        try (ResultSet rs = st.executeQuery(sql)) {
            rs.next();
            return rs.getDouble(1);
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnDashboard;
    private javax.swing.JButton btnLogout;
    private javax.swing.JButton btnManageCategory;
    private javax.swing.JButton btnManagementProduct;
    private javax.swing.JButton btnRefresh;
    private javax.swing.JButton btnReports;
    private javax.swing.JButton btnSalesOrder;
    private javax.swing.JLabel lblCap1;
    private javax.swing.JLabel lblCap2;
    private javax.swing.JLabel lblCap3;
    private javax.swing.JLabel lblCap4;
    private javax.swing.JLabel lblCategories;
    private javax.swing.JLabel lblDate;
    private javax.swing.JLabel lblLogo;
    private javax.swing.JLabel lblOrders;
    private javax.swing.JLabel lblProducts;
    private javax.swing.JLabel lblRecent;
    private javax.swing.JLabel lblSales;
    private javax.swing.JLabel lblSidebarSub;
    private javax.swing.JLabel lblWelcome;
    private javax.swing.JPanel pnlCard1;
    private javax.swing.JPanel pnlCard2;
    private javax.swing.JPanel pnlCard3;
    private javax.swing.JPanel pnlCard4;
    private javax.swing.JPanel pnlContent;
    private javax.swing.JPanel pnlRoot;
    private javax.swing.JPanel pnlSidebar;
    private javax.swing.JScrollPane spRecent;
    private javax.swing.JTable tblRecent;
    // End of variables declaration//GEN-END:variables
}
