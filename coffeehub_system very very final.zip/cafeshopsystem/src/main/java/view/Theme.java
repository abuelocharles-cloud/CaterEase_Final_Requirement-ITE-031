package view;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import javax.swing.BorderFactory;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JViewport;
import javax.swing.SwingConstants;
import javax.swing.UIDefaults;
import javax.swing.UIManager;
import javax.swing.plaf.ColorUIResource;
import javax.swing.plaf.FontUIResource;
import javax.swing.plaf.metal.MetalLookAndFeel;
import javax.swing.plaf.metal.OceanTheme;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;

/**
 * Shared colors and small helpers used by every form.
 * The layout itself lives in each form's .form file (open it in the NetBeans Design tab);
 * this class only adds the finishing touches (table style, text-field style, messages).
 */
public class Theme {

    public static final Color DARK = new Color(59, 36, 24);          // espresso
    public static final Color BROWN = new Color(111, 78, 55);        // mocha
    public static final Color LIGHT_BROWN = new Color(166, 123, 91); // latte
    public static final Color CREAM = new Color(245, 236, 224);
    public static final Color WHITE = Color.WHITE;
    public static final Color TEXT = new Color(33, 24, 20);

    public static final Font FONT = new Font("Segoe UI", Font.PLAIN, 14);
    public static final Font BOLD = new Font("Segoe UI", Font.BOLD, 14);

    /** Currency symbol shown in front of money. Change to "P " if the peso sign does not display. */
    public static final String CURRENCY = "\u20B1 ";

    private static final SimpleDateFormat DATE_TIME = new SimpleDateFormat("MMM dd, yyyy  hh:mm a");

    private Theme() { }

    /** Called once when the program starts (see Cafeshopsystem.java). */
    public static void install() {
        try {
            MetalLookAndFeel.setCurrentTheme(new CoffeeTheme());   // brown instead of Java's default blue
            UIManager.setLookAndFeel(new MetalLookAndFeel());
        } catch (Exception ex) {
            // keep the default look if it fails
        }
        UIManager.put("ScrollBarUI", "view.CoffeeScrollBarUI");    // slim brown scroll bars
        UIManager.put("Panel.background", CREAM);
        UIManager.put("OptionPane.background", CREAM);
        UIManager.put("OptionPane.messageFont", FONT);
        UIManager.put("OptionPane.buttonFont", BOLD);
        UIManager.put("ComboBox.font", FONT);
        UIManager.put("ComboBox.background", WHITE);
        UIManager.put("ComboBox.selectionBackground", LIGHT_BROWN);
        UIManager.put("ComboBox.selectionForeground", WHITE);
        UIManager.put("List.selectionBackground", LIGHT_BROWN);
        UIManager.put("List.selectionForeground", WHITE);
        UIManager.put("Spinner.font", FONT);
        UIManager.put("Label.font", FONT);
    }

    /** The coffee colors for Java's Metal look: replaces the blue-gray of the default theme. */
    private static class CoffeeTheme extends OceanTheme {
        private final ColorUIResource p1 = new ColorUIResource(111, 78, 55);
        private final ColorUIResource p2 = new ColorUIResource(166, 123, 91);
        private final ColorUIResource p3 = new ColorUIResource(222, 205, 186);
        private final ColorUIResource s1 = new ColorUIResource(176, 150, 128);
        private final ColorUIResource s2 = new ColorUIResource(214, 196, 178);
        private final ColorUIResource s3 = new ColorUIResource(245, 236, 224);
        private final FontUIResource font = new FontUIResource("Segoe UI", Font.PLAIN, 14);

        @Override public String getName() { return "Coffee"; }
        @Override protected ColorUIResource getPrimary1() { return p1; }
        @Override protected ColorUIResource getPrimary2() { return p2; }
        @Override protected ColorUIResource getPrimary3() { return p3; }
        @Override protected ColorUIResource getSecondary1() { return s1; }
        @Override protected ColorUIResource getSecondary2() { return s2; }
        @Override protected ColorUIResource getSecondary3() { return s3; }
        @Override public FontUIResource getControlTextFont() { return font; }
        @Override public FontUIResource getSystemTextFont() { return font; }
        @Override public FontUIResource getUserTextFont() { return font; }
        @Override public FontUIResource getMenuTextFont() { return font; }

        @Override
        public void addCustomEntriesToTable(UIDefaults table) {
            super.addCustomEntriesToTable(table);
            // the default theme paints blue gradients on buttons / spinner arrows: make them flat cream
            java.util.List<Object> flat = java.util.Arrays.asList(0.3f, 0.0f,
                    new ColorUIResource(240, 230, 218), new ColorUIResource(255, 255, 255),
                    new ColorUIResource(222, 205, 186));
            for (Object key : new java.util.ArrayList<>(table.keySet())) {
                if (key instanceof String && ((String) key).endsWith(".gradient")) {
                    table.put(key, flat);
                }
            }
        }
    }

    // ---------------- messages ----------------
    public static String money(double value) {
        return CURRENCY + new DecimalFormat("#,##0.00").format(value);
    }

    public static String dateTime(Timestamp t) {
        return t == null ? "" : DATE_TIME.format(t);
    }

    public static void warn(Component parent, String message) {
        JOptionPane.showMessageDialog(parent, message, "Please check", JOptionPane.WARNING_MESSAGE);
    }

    public static boolean confirm(Component parent, String message) {
        return JOptionPane.showConfirmDialog(parent, message, "Please confirm",
                JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE) == JOptionPane.YES_OPTION;
    }

    public static void dbError(Component parent, Exception ex) {
        JOptionPane.showMessageDialog(parent,
                "Database error:\n" + ex.getMessage()
                + "\n\nCheck that MySQL (XAMPP) is running and the coffee_shop database is imported.",
                "Database Error", JOptionPane.ERROR_MESSAGE);
    }

    // ---------------- styling ----------------
    /** Nicer text field: thin brown border with padding. */
    public static void styleField(JTextField f) {
        f.setFont(FONT);
        f.setForeground(TEXT);
        f.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 180, 160)),
                new EmptyBorder(6, 10, 6, 10)));
    }

    /** Brown header, striped rows, no grid lines. Call once after initComponents(). */
    public static void styleTable(JTable t) {
        t.setRowHeight(34);
        t.setFont(FONT);
        t.setForeground(TEXT);
        t.setShowGrid(false);
        t.setIntercellSpacing(new Dimension(0, 0));
        t.setSelectionBackground(LIGHT_BROWN);
        t.setSelectionForeground(WHITE);
        t.setFillsViewportHeight(true);
        t.setDefaultRenderer(Object.class, new CellRenderer(false));

        JTableHeader h = t.getTableHeader();
        h.setReorderingAllowed(false);
        h.setPreferredSize(new Dimension(0, 38));
        h.setDefaultRenderer(new HeaderRenderer(false));

        Container parent = t.getParent();
        if (parent instanceof JViewport && parent.getParent() instanceof JScrollPane) {
            JScrollPane sp = (JScrollPane) parent.getParent();
            sp.setBorder(BorderFactory.createLineBorder(new Color(220, 205, 190)));
            sp.getViewport().setBackground(WHITE);
        }
    }

    /** Show these columns as money (e.g. 1,250.00) and right-aligned. */
    public static void moneyColumns(JTable table, int... columns) {
        for (int c : columns) {
            table.getColumnModel().getColumn(c).setCellRenderer(new CellRenderer(true));
            table.getColumnModel().getColumn(c).setHeaderRenderer(new HeaderRenderer(true));   // header lines up with the numbers
        }
    }

    /** Dark brown table heading; right-aligned for money columns. */
    private static class HeaderRenderer extends DefaultTableCellRenderer {
        private final boolean right;

        HeaderRenderer(boolean right) {
            this.right = right;
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column) {
            super.getTableCellRendererComponent(table, value, false, false, row, column);
            setBackground(DARK);
            setForeground(WHITE);
            setFont(BOLD);
            setBorder(new EmptyBorder(0, 10, 0, 10));
            setHorizontalAlignment(right ? SwingConstants.RIGHT : SwingConstants.LEFT);
            return this;
        }
    }

    /** Draws striped rows and formats money columns. */
    private static class CellRenderer extends DefaultTableCellRenderer {
        private final boolean isMoney;

        CellRenderer(boolean isMoney) {
            this.isMoney = isMoney;
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column) {
            super.getTableCellRendererComponent(table, value, isSelected, false, row, column);
            if (isMoney && value instanceof Number) {
                setText(money(((Number) value).doubleValue()));
            }
            setHorizontalAlignment(isMoney ? SwingConstants.RIGHT : SwingConstants.LEFT);
            setBorder(new EmptyBorder(0, 10, 0, 10));
            if (!isSelected) {
                setBackground(row % 2 == 0 ? WHITE : CREAM);
            }
            return this;
        }
    }
}
