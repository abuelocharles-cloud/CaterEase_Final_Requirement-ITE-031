package view;

import controller.CartManager;
import database.database;
import java.awt.print.PrinterException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Shows the printable receipt of one order (read back from the database).
 * Design this window in the NetBeans Design tab (see Receipt.form).
 */
public class Receipt extends javax.swing.JFrame {

    private static final int WIDTH = 41;   // characters per line

    public Receipt(int orderId) {
        initComponents();
        txtReceipt.setMargin(new java.awt.Insets(20, 22, 20, 22));
        loadReceipt(orderId);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlRoot = new view.BackgroundPanel();
        spReceipt = new javax.swing.JScrollPane();
        txtReceipt = new javax.swing.JTextArea();
        btnPrint = new view.RoundButton();
        btnNewOrder = new view.RoundButton();
        btnMenu = new view.RoundButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Receipt - Coffee Hub System"); // NOI18N

        pnlRoot.setPreferredSize(new java.awt.Dimension(560, 760));
        txtReceipt.setBackground(new java.awt.Color(255, 255, 255));
        txtReceipt.setEditable(false);
        txtReceipt.setFont(new java.awt.Font("Monospaced", 0, 14)); // NOI18N
        txtReceipt.setForeground(new java.awt.Color(33, 24, 20));
        btnPrint.setBackground(new java.awt.Color(111, 78, 55));
        btnPrint.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnPrint.setForeground(new java.awt.Color(255, 255, 255));
        btnPrint.setText("PRINT"); // NOI18N
        btnPrint.addActionListener(this::btnPrintActionPerformed);
        btnNewOrder.setBackground(new java.awt.Color(59, 36, 24));
        btnNewOrder.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnNewOrder.setForeground(new java.awt.Color(255, 255, 255));
        btnNewOrder.setText("NEW ORDER"); // NOI18N
        btnNewOrder.addActionListener(this::btnNewOrderActionPerformed);
        btnMenu.setBackground(new java.awt.Color(166, 123, 91));
        btnMenu.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnMenu.setForeground(new java.awt.Color(255, 255, 255));
        btnMenu.setText("MAIN MENU"); // NOI18N
        btnMenu.addActionListener(this::btnMenuActionPerformed);
        spReceipt.setViewportView(txtReceipt);

        javax.swing.GroupLayout pnlRootLayout = new javax.swing.GroupLayout(pnlRoot);
        pnlRoot.setLayout(pnlRootLayout);
        pnlRootLayout.setHorizontalGroup(
            pnlRootLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlRootLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(spReceipt, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(30, 30, 30)
            )
            .addGroup(pnlRootLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(btnPrint, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(btnNewOrder, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(btnMenu, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE)
                .addGap(30, 30, 30)
            )
        );
        pnlRootLayout.setVerticalGroup(
            pnlRootLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlRootLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(spReceipt, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(14, 14, 14)
                .addGroup(pnlRootLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnPrint, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnNewOrder, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnMenu, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                )
                .addGap(22, 22, 22)
            )
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnlRoot, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            )
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnlRoot, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            )
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnPrintActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPrintActionPerformed
        try {
            txtReceipt.print();
        } catch (PrinterException ex) {
            Theme.warn(this, "Could not print: " + ex.getMessage());
        }
    }//GEN-LAST:event_btnPrintActionPerformed

    private void btnNewOrderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNewOrderActionPerformed
        CartManager.clear();
        new CustomerDashboard().setVisible(true);
        dispose();
    }//GEN-LAST:event_btnNewOrderActionPerformed

    private void btnMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMenuActionPerformed
        new mainframe().setVisible(true);
        dispose();
    }//GEN-LAST:event_btnMenuActionPerformed

    private void loadReceipt(int orderId) {
        StringBuilder sb = new StringBuilder();
        try (Connection con = database.getConnection()) {
            try (PreparedStatement ps = con.prepareStatement(
                    "SELECT order_date, customer_name, total_amount, cash_amount, change_amount "
                    + "FROM orders WHERE id = ?")) {
                ps.setInt(1, orderId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (!rs.next()) {
                        txtReceipt.setText("Order not found.");
                        return;
                    }
                    sb.append(center("COFFEE HUB")).append('\n');
                    sb.append(center("Coffee Hub System")).append('\n');
                    sb.append(center("Thank you for your order!")).append("\n\n");
                    sb.append(line('-')).append('\n');
                    sb.append(String.format("Order #  : %04d%n", orderId));
                    sb.append("Date     : ").append(Theme.dateTime(rs.getTimestamp("order_date"))).append('\n');
                    sb.append("Customer : ").append(rs.getString("customer_name")).append('\n');
                    sb.append(line('-')).append('\n');
                    sb.append(String.format("%-18s %3s %8s %9s%n", "ITEM", "QTY", "PRICE", "AMOUNT"));
                    sb.append(line('-')).append('\n');

                    try (PreparedStatement psItems = con.prepareStatement(
                            "SELECT product_name, quantity, price, subtotal FROM order_items "
                            + "WHERE order_id = ? ORDER BY id")) {
                        psItems.setInt(1, orderId);
                        try (ResultSet items = psItems.executeQuery()) {
                            while (items.next()) {
                                sb.append(String.format("%-18.18s %3d %8.2f %9.2f%n",
                                        items.getString("product_name"), items.getInt("quantity"),
                                        items.getDouble("price"), items.getDouble("subtotal")));
                            }
                        }
                    }

                    sb.append(line('-')).append('\n');
                    sb.append(String.format("%-31s %9.2f%n", "TOTAL (PHP)", rs.getDouble("total_amount")));
                    sb.append(String.format("%-31s %9.2f%n", "CASH", rs.getDouble("cash_amount")));
                    sb.append(String.format("%-31s %9.2f%n", "CHANGE", rs.getDouble("change_amount")));
                    sb.append(line('-')).append("\n\n");
                    sb.append(center("Please come again!")).append('\n');
                }
            }
        } catch (SQLException ex) {
            Theme.dbError(this, ex);
        }
        txtReceipt.setText(sb.toString());
        txtReceipt.setCaretPosition(0);
    }

    private String center(String s) {
        int pad = Math.max(0, (WIDTH - s.length()) / 2);
        return " ".repeat(pad) + s;
    }

    private String line(char c) {
        return String.valueOf(c).repeat(WIDTH);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnMenu;
    private javax.swing.JButton btnNewOrder;
    private javax.swing.JButton btnPrint;
    private javax.swing.JPanel pnlRoot;
    private javax.swing.JScrollPane spReceipt;
    private javax.swing.JTextArea txtReceipt;
    // End of variables declaration//GEN-END:variables
}
