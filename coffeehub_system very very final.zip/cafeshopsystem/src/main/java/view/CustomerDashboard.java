package view;

import controller.CartManager;
import controller.CategoryItem;
import database.database;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.table.DefaultTableModel;

/**
 * Customer side: browse products, filter by category, add to cart. No login needed.
 * Design this window in the NetBeans Design tab (see CustomerDashboard.form).
 */
public class CustomerDashboard extends javax.swing.JFrame {

    /** true while the category list is being loaded (so the combo box does not reload products) */
    private boolean loading = false;

    public CustomerDashboard() {
        initComponents();
        sprQuantity.setModel(new javax.swing.SpinnerNumberModel(1, 1, 99, 1));
        Theme.styleField(txtSearch);
        Theme.styleTable(tblProducts);
        Theme.moneyColumns(tblProducts, 3);
        // customers do not need the ID: hide the column (the data is still in the table model)
        tblProducts.removeColumn(tblProducts.getColumnModel().getColumn(0));
        ((javax.swing.JSpinner.DefaultEditor) sprQuantity.getEditor()).getTextField()
                .setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        loadCategories();
        loadProducts();
        refreshCartInfo();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlRoot = new javax.swing.JPanel();
        pnlHeader = new javax.swing.JPanel();
        lblHeaderTitle = new javax.swing.JLabel();
        lblHeaderSub = new javax.swing.JLabel();
        lblCategory = new javax.swing.JLabel();
        cmbCategories = new javax.swing.JComboBox<>();
        lblSearch = new javax.swing.JLabel();
        txtSearch = new javax.swing.JTextField();
        spProducts = new javax.swing.JScrollPane();
        tblProducts = new javax.swing.JTable();
        lblQuantity = new javax.swing.JLabel();
        sprQuantity = new javax.swing.JSpinner();
        btnAddToCart = new view.RoundButton();
        lblCartInfo = new javax.swing.JLabel();
        btnViewCart = new view.RoundButton();
        btnBack = new view.RoundButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Order - Coffee Hub System"); // NOI18N

        pnlRoot.setBackground(new java.awt.Color(245, 236, 224));
        pnlRoot.setPreferredSize(new java.awt.Dimension(1100, 700));
        pnlHeader.setBackground(new java.awt.Color(59, 36, 24));
        lblHeaderTitle.setFont(new java.awt.Font("Georgia", 1, 26)); // NOI18N
        lblHeaderTitle.setForeground(new java.awt.Color(255, 255, 255));
        lblHeaderTitle.setText("COFFEE HUB SYSTEM  -  Order"); // NOI18N
        lblHeaderSub.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblHeaderSub.setForeground(new java.awt.Color(215, 190, 165));
        lblHeaderSub.setText("Pick your drinks and treats, then add them to your cart"); // NOI18N
        lblCategory.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblCategory.setForeground(new java.awt.Color(33, 24, 20));
        lblCategory.setText("Category:"); // NOI18N
        cmbCategories.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        cmbCategories.addActionListener(this::cmbCategoriesActionPerformed);
        lblSearch.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblSearch.setForeground(new java.awt.Color(33, 24, 20));
        lblSearch.setText("Search:"); // NOI18N
        txtSearch.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtSearch.setForeground(new java.awt.Color(33, 24, 20));
        txtSearch.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtSearchKeyReleased(evt);
            }
        });
        tblProducts.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Product", "Category", "Price", "Stock"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        lblQuantity.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblQuantity.setForeground(new java.awt.Color(33, 24, 20));
        lblQuantity.setText("Quantity:"); // NOI18N
        sprQuantity.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnAddToCart.setBackground(new java.awt.Color(111, 78, 55));
        btnAddToCart.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnAddToCart.setForeground(new java.awt.Color(255, 255, 255));
        btnAddToCart.setText("ADD TO CART"); // NOI18N
        btnAddToCart.addActionListener(this::btnAddToCartActionPerformed);
        lblCartInfo.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        lblCartInfo.setForeground(new java.awt.Color(59, 36, 24));
        lblCartInfo.setText("Cart: 0 item(s)"); // NOI18N
        btnViewCart.setBackground(new java.awt.Color(59, 36, 24));
        btnViewCart.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnViewCart.setForeground(new java.awt.Color(255, 255, 255));
        btnViewCart.setText("VIEW CART"); // NOI18N
        btnViewCart.addActionListener(this::btnViewCartActionPerformed);
        btnBack.setBackground(new java.awt.Color(166, 123, 91));
        btnBack.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnBack.setForeground(new java.awt.Color(255, 255, 255));
        btnBack.setText("BACK"); // NOI18N
        btnBack.addActionListener(this::btnBackActionPerformed);
        spProducts.setViewportView(tblProducts);

        javax.swing.GroupLayout pnlHeaderLayout = new javax.swing.GroupLayout(pnlHeader);
        pnlHeader.setLayout(pnlHeaderLayout);
        pnlHeaderLayout.setHorizontalGroup(
            pnlHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlHeaderLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(lblHeaderTitle, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(28, 28, 28)
            )
            .addGroup(pnlHeaderLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(lblHeaderSub, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(28, 28, 28)
            )
        );
        pnlHeaderLayout.setVerticalGroup(
            pnlHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlHeaderLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(lblHeaderTitle)
                .addGap(2, 2, 2)
                .addComponent(lblHeaderSub)
                .addGap(16, 16, 16)
            )
        );

        javax.swing.GroupLayout pnlRootLayout = new javax.swing.GroupLayout(pnlRoot);
        pnlRoot.setLayout(pnlRootLayout);
        pnlRootLayout.setHorizontalGroup(
            pnlRootLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlRootLayout.createSequentialGroup()
                .addComponent(pnlHeader, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            )
            .addGroup(pnlRootLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(lblCategory)
                .addGap(10, 10, 10)
                .addComponent(cmbCategories, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(16, 16, 16)
                .addComponent(lblSearch)
                .addGap(10, 10, 10)
                .addComponent(txtSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24)
            )
            .addGroup(pnlRootLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(spProducts, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(24, 24, 24)
            )
            .addGroup(pnlRootLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(lblQuantity)
                .addGap(10, 10, 10)
                .addComponent(sprQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(btnAddToCart, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(lblCartInfo)
                .addGap(12, 12, 12)
                .addComponent(btnViewCart, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(btnBack, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24)
            )
        );
        pnlRootLayout.setVerticalGroup(
            pnlRootLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlRootLayout.createSequentialGroup()
                .addComponent(pnlHeader)
                .addGap(18, 18, 18)
                .addGroup(pnlRootLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblCategory, javax.swing.GroupLayout.Alignment.CENTER, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbCategories, javax.swing.GroupLayout.Alignment.CENTER, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblSearch, javax.swing.GroupLayout.Alignment.CENTER, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtSearch, javax.swing.GroupLayout.Alignment.CENTER, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                )
                .addGap(14, 14, 14)
                .addComponent(spProducts, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(14, 14, 14)
                .addGroup(pnlRootLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(lblQuantity, javax.swing.GroupLayout.Alignment.CENTER, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(sprQuantity, javax.swing.GroupLayout.Alignment.CENTER, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAddToCart, javax.swing.GroupLayout.Alignment.CENTER, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblCartInfo, javax.swing.GroupLayout.Alignment.CENTER, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnViewCart, javax.swing.GroupLayout.Alignment.CENTER, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBack, javax.swing.GroupLayout.Alignment.CENTER, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                )
                .addGap(20, 20, 20)
            )
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnlRoot, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            )
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnlRoot, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            )
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void cmbCategoriesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbCategoriesActionPerformed
        if (!loading) {
            loadProducts();
        }
    }//GEN-LAST:event_cmbCategoriesActionPerformed

    private void txtSearchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtSearchKeyReleased
        loadProducts();
    }//GEN-LAST:event_txtSearchKeyReleased

    private void btnAddToCartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddToCartActionPerformed
        int row = tblProducts.getSelectedRow();
        if (row < 0) {
            Theme.warn(this, "Please click a product in the table first.");
            return;
        }
        DefaultTableModel model = (DefaultTableModel) tblProducts.getModel();
        int id = (int) model.getValueAt(row, 0);
        String name = String.valueOf(model.getValueAt(row, 1));
        double price = ((Number) model.getValueAt(row, 3)).doubleValue();
        int stock = (int) model.getValueAt(row, 4);
        int qty = (int) sprQuantity.getValue();
        int alreadyInCart = CartManager.getQuantityOf(id);

        if (qty + alreadyInCart > stock) {
            Theme.warn(this, "Sorry, only " + stock + " \"" + name + "\" in stock"
                    + (alreadyInCart > 0 ? " (you already have " + alreadyInCart + " in your cart)." : "."));
            return;
        }
        CartManager.addItem(id, name, price, qty);
        sprQuantity.setValue(1);
        refreshCartInfo();
    }//GEN-LAST:event_btnAddToCartActionPerformed

    private void btnViewCartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewCartActionPerformed
        Cart cart = new Cart();
        cart.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent e) {
                refreshCartInfo();   // the customer may have removed items
                loadProducts();
            }
        });
        cart.setVisible(true);
    }//GEN-LAST:event_btnViewCartActionPerformed

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        if (CartManager.getCount() > 0
                && !Theme.confirm(this, "Your cart will be emptied if you go back. Continue?")) {
            return;
        }
        CartManager.clear();
        new mainframe().setVisible(true);
        dispose();
    }//GEN-LAST:event_btnBackActionPerformed

    private void loadCategories() {
        loading = true;
        cmbCategories.removeAllItems();
        cmbCategories.addItem(new CategoryItem(0, "All Categories"));
        try (Connection con = database.getConnection();
                Statement st = con.createStatement();
                ResultSet rs = st.executeQuery("SELECT id, name FROM categories ORDER BY name")) {
            while (rs.next()) {
                cmbCategories.addItem(new CategoryItem(rs.getInt("id"), rs.getString("name")));
            }
        } catch (SQLException ex) {
            Theme.dbError(this, ex);
        }
        loading = false;
    }

    private void loadProducts() {
        DefaultTableModel model = (DefaultTableModel) tblProducts.getModel();
        model.setRowCount(0);
        CategoryItem cat = (CategoryItem) cmbCategories.getSelectedItem();
        int categoryId = (cat == null) ? 0 : cat.getId();
        String sql = "SELECT p.id, p.name, c.name AS category, p.price, p.stock "
                + "FROM products p JOIN categories c ON c.id = p.category_id "
                + "WHERE p.name LIKE ? AND (? = 0 OR p.category_id = ?) "
                + "ORDER BY c.name, p.name";
        try (Connection con = database.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, "%" + txtSearch.getText().trim() + "%");
            ps.setInt(2, categoryId);
            ps.setInt(3, categoryId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    model.addRow(new Object[]{rs.getInt("id"), rs.getString("name"),
                        rs.getString("category"), rs.getDouble("price"), rs.getInt("stock")});
                }
            }
        } catch (SQLException ex) {
            Theme.dbError(this, ex);
        }
    }

    private void refreshCartInfo() {
        lblCartInfo.setText("Cart: " + CartManager.getCount() + " item(s)  |  "
                + Theme.money(CartManager.getTotal()));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAddToCart;
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnViewCart;
    private javax.swing.JComboBox<controller.CategoryItem> cmbCategories;
    private javax.swing.JLabel lblCartInfo;
    private javax.swing.JLabel lblCategory;
    private javax.swing.JLabel lblHeaderSub;
    private javax.swing.JLabel lblHeaderTitle;
    private javax.swing.JLabel lblQuantity;
    private javax.swing.JLabel lblSearch;
    private javax.swing.JPanel pnlHeader;
    private javax.swing.JPanel pnlRoot;
    private javax.swing.JScrollPane spProducts;
    private javax.swing.JSpinner sprQuantity;
    private javax.swing.JTable tblProducts;
    private javax.swing.JTextField txtSearch;
    // End of variables declaration//GEN-END:variables
}
