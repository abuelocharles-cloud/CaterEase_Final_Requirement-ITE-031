package view;

import controller.CartItem;
import controller.CartManager;
import database.database;
import java.awt.Frame;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.table.DefaultTableModel;

/**
 * Checkout: order summary, cash received, and saving the order in ONE database transaction.
 * Design this window in the NetBeans Design tab (see Checkout.form).
 */
public class Checkout extends javax.swing.JFrame {

    public Checkout() {
        initComponents();
        Theme.styleField(txtCustomer);
        Theme.styleField(txtCash);
        Theme.styleTable(tblSummary);
        Theme.moneyColumns(tblSummary, 2);

        DefaultTableModel model = (DefaultTableModel) tblSummary.getModel();
        for (CartItem item : CartManager.getItems()) {
            model.addRow(new Object[]{item.getProductName(), item.getQuantity(), item.getSubtotal()});
        }
        lblOrderTotal.setText("ORDER TOTAL: " + Theme.money(CartManager.getTotal()));
        getRootPane().setDefaultButton(btnConfirmOrder);   // Enter = CONFIRM
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlRoot = new javax.swing.JPanel();
        pnlHeader = new javax.swing.JPanel();
        lblHeaderTitle = new javax.swing.JLabel();
        lblHeaderSub = new javax.swing.JLabel();
        spSummary = new javax.swing.JScrollPane();
        tblSummary = new javax.swing.JTable();
        pnlPay = new view.RoundPanel();
        lblOrderTotal = new javax.swing.JLabel();
        lblCustomer = new javax.swing.JLabel();
        txtCustomer = new javax.swing.JTextField();
        lblCash = new javax.swing.JLabel();
        txtCash = new javax.swing.JTextField();
        lblChange = new javax.swing.JLabel();
        btnCancel = new view.RoundButton();
        btnConfirmOrder = new view.RoundButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Checkout - Coffee Hub System"); // NOI18N

        pnlRoot.setBackground(new java.awt.Color(245, 236, 224));
        pnlRoot.setPreferredSize(new java.awt.Dimension(560, 640));
        pnlHeader.setBackground(new java.awt.Color(59, 36, 24));
        lblHeaderTitle.setFont(new java.awt.Font("Georgia", 1, 26)); // NOI18N
        lblHeaderTitle.setForeground(new java.awt.Color(255, 255, 255));
        lblHeaderTitle.setText("Checkout"); // NOI18N
        lblHeaderSub.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblHeaderSub.setForeground(new java.awt.Color(215, 190, 165));
        lblHeaderSub.setText("Enter the cash received and confirm the order"); // NOI18N
        tblSummary.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Item", "Qty", "Subtotal"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        pnlPay.setBackground(new java.awt.Color(255, 255, 255));
        lblOrderTotal.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        lblOrderTotal.setForeground(new java.awt.Color(59, 36, 24));
        lblOrderTotal.setText("ORDER TOTAL: \u20B1 0.00"); // NOI18N
        lblCustomer.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblCustomer.setForeground(new java.awt.Color(33, 24, 20));
        lblCustomer.setText("Customer name (optional)"); // NOI18N
        txtCustomer.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtCustomer.setForeground(new java.awt.Color(33, 24, 20));
        lblCash.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblCash.setForeground(new java.awt.Color(33, 24, 20));
        lblCash.setText("Cash received"); // NOI18N
        txtCash.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtCash.setForeground(new java.awt.Color(33, 24, 20));
        txtCash.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtCashKeyReleased(evt);
            }
        });
        lblChange.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblChange.setForeground(new java.awt.Color(111, 78, 55));
        lblChange.setText("Change: \u20B1 0.00"); // NOI18N
        btnCancel.setBackground(new java.awt.Color(166, 123, 91));
        btnCancel.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnCancel.setForeground(new java.awt.Color(255, 255, 255));
        btnCancel.setText("CANCEL"); // NOI18N
        btnCancel.addActionListener(this::btnCancelActionPerformed);
        btnConfirmOrder.setBackground(new java.awt.Color(111, 78, 55));
        btnConfirmOrder.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnConfirmOrder.setForeground(new java.awt.Color(255, 255, 255));
        btnConfirmOrder.setText("CONFIRM ORDER"); // NOI18N
        btnConfirmOrder.addActionListener(this::btnConfirmOrderActionPerformed);
        spSummary.setViewportView(tblSummary);

        javax.swing.GroupLayout pnlHeaderLayout = new javax.swing.GroupLayout(pnlHeader);
        pnlHeader.setLayout(pnlHeaderLayout);
        pnlHeaderLayout.setHorizontalGroup(
            pnlHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlHeaderLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(lblHeaderTitle, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(28, 28, 28)
            )
            .addGroup(pnlHeaderLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(lblHeaderSub, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(28, 28, 28)
            )
        );
        pnlHeaderLayout.setVerticalGroup(
            pnlHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlHeaderLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(lblHeaderTitle)
                .addGap(2, 2, 2)
                .addComponent(lblHeaderSub)
                .addGap(16, 16, 16)
            )
        );

        javax.swing.GroupLayout pnlPayLayout = new javax.swing.GroupLayout(pnlPay);
        pnlPay.setLayout(pnlPayLayout);
        pnlPayLayout.setHorizontalGroup(
            pnlPayLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlPayLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(lblOrderTotal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(22, 22, 22)
            )
            .addGroup(pnlPayLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(lblCustomer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(22, 22, 22)
            )
            .addGroup(pnlPayLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(txtCustomer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(22, 22, 22)
            )
            .addGroup(pnlPayLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(lblCash, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(22, 22, 22)
            )
            .addGroup(pnlPayLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(txtCash, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(22, 22, 22)
            )
            .addGroup(pnlPayLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(lblChange, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(22, 22, 22)
            )
            .addGroup(pnlPayLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(btnCancel, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(btnConfirmOrder, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22)
            )
        );
        pnlPayLayout.setVerticalGroup(
            pnlPayLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlPayLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(lblOrderTotal)
                .addGap(14, 14, 14)
                .addComponent(lblCustomer)
                .addGap(6, 6, 6)
                .addComponent(txtCustomer, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(lblCash)
                .addGap(6, 6, 6)
                .addComponent(txtCash, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14)
                .addComponent(lblChange)
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(pnlPayLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnCancel, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnConfirmOrder, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                )
                .addGap(18, 18, 18)
            )
        );

        javax.swing.GroupLayout pnlRootLayout = new javax.swing.GroupLayout(pnlRoot);
        pnlRoot.setLayout(pnlRootLayout);
        pnlRootLayout.setHorizontalGroup(
            pnlRootLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlRootLayout.createSequentialGroup()
                .addComponent(pnlHeader, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            )
            .addGroup(pnlRootLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(spSummary, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(24, 24, 24)
            )
            .addGroup(pnlRootLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(pnlPay, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(24, 24, 24)
            )
        );
        pnlRootLayout.setVerticalGroup(
            pnlRootLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlRootLayout.createSequentialGroup()
                .addComponent(pnlHeader)
                .addGap(20, 20, 20)
                .addComponent(spSummary, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14)
                .addComponent(pnlPay, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(20, 20, 20)
            )
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnlRoot, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            )
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnlRoot, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            )
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txtCashKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCashKeyReleased
        updateChange();
    }//GEN-LAST:event_txtCashKeyReleased

    private void btnCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelActionPerformed
        dispose();
    }//GEN-LAST:event_btnCancelActionPerformed

    private void btnConfirmOrderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConfirmOrderActionPerformed
        double total = CartManager.getTotal();
        double cash;
        try {
            cash = Double.parseDouble(txtCash.getText().trim());
        } catch (NumberFormatException ex) {
            Theme.warn(this, "Please enter the cash received, for example 500.");
            return;
        }
        if (cash < total) {
            Theme.warn(this, "The cash is not enough. The total is " + Theme.money(total) + ".");
            return;
        }
        String customer = txtCustomer.getText().trim();
        if (customer.isEmpty()) {
            customer = "Walk-in";
        }

        int orderId;
        try (Connection con = database.getConnection()) {
            con.setAutoCommit(false);              // start of the transaction
            try {
                orderId = saveOrder(con, customer, total, cash);
                con.commit();                      // everything saved
            } catch (SQLException ex) {
                con.rollback();                    // something failed: save nothing
                Theme.warn(this, ex.getMessage());
                return;
            }
        } catch (SQLException ex) {
            Theme.dbError(this, ex);
            return;
        }

        // success: empty the cart, close the customer windows, show the receipt
        CartManager.clear();
        for (Frame f : Frame.getFrames()) {
            if (f instanceof CustomerDashboard || f instanceof Cart || f == this) {
                f.dispose();
            }
        }
        new Receipt(orderId).setVisible(true);
    }//GEN-LAST:event_btnConfirmOrderActionPerformed

    /** Shows the change (or how much is missing) while the cashier types. */
    private void updateChange() {
        try {
            double cash = Double.parseDouble(txtCash.getText().trim());
            double change = cash - CartManager.getTotal();
            lblChange.setText(change >= 0 ? "Change: " + Theme.money(change)
                    : "Short by: " + Theme.money(-change));
        } catch (NumberFormatException ex) {
            lblChange.setText("Change: " + Theme.money(0));
        }
    }

    /** Inserts the order and its items, and lowers the stock. Returns the new order id. */
    private int saveOrder(Connection con, String customer, double total, double cash) throws SQLException {
        int orderId;
        double change = Math.round((cash - total) * 100) / 100.0;

        // the order time comes from this program (Philippine time), not from the MySQL server clock
        String sqlOrder = "INSERT INTO orders (order_date, customer_name, total_amount, cash_amount, change_amount) "
                + "VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement ps = con.prepareStatement(sqlOrder, Statement.RETURN_GENERATED_KEYS)) {
            ps.setTimestamp(1, new java.sql.Timestamp(System.currentTimeMillis()));
            ps.setString(2, customer);
            ps.setDouble(3, total);
            ps.setDouble(4, cash);
            ps.setDouble(5, change);
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                keys.next();
                orderId = keys.getInt(1);
            }
        }

        String sqlItem = "INSERT INTO order_items (order_id, product_id, product_name, price, quantity, subtotal) "
                + "VALUES (?, ?, ?, ?, ?, ?)";
        // "stock >= ?" makes sure two customers cannot buy the last piece at the same time
        String sqlStock = "UPDATE products SET stock = stock - ? WHERE id = ? AND stock >= ?";
        try (PreparedStatement psItem = con.prepareStatement(sqlItem);
                PreparedStatement psStock = con.prepareStatement(sqlStock)) {
            for (CartItem item : CartManager.getItems()) {
                psStock.setInt(1, item.getQuantity());
                psStock.setInt(2, item.getProductId());
                psStock.setInt(3, item.getQuantity());
                if (psStock.executeUpdate() == 0) {
                    throw new SQLException("Not enough stock for \"" + item.getProductName()
                            + "\". Please update your cart.");
                }
                psItem.setInt(1, orderId);
                psItem.setInt(2, item.getProductId());
                psItem.setString(3, item.getProductName());
                psItem.setDouble(4, item.getPrice());
                psItem.setInt(5, item.getQuantity());
                psItem.setDouble(6, item.getSubtotal());
                psItem.executeUpdate();
            }
        }
        return orderId;
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancel;
    private javax.swing.JButton btnConfirmOrder;
    private javax.swing.JLabel lblCash;
    private javax.swing.JLabel lblChange;
    private javax.swing.JLabel lblCustomer;
    private javax.swing.JLabel lblHeaderSub;
    private javax.swing.JLabel lblHeaderTitle;
    private javax.swing.JLabel lblOrderTotal;
    private javax.swing.JPanel pnlHeader;
    private javax.swing.JPanel pnlPay;
    private javax.swing.JPanel pnlRoot;
    private javax.swing.JScrollPane spSummary;
    private javax.swing.JTable tblSummary;
    private javax.swing.JTextField txtCash;
    private javax.swing.JTextField txtCustomer;
    // End of variables declaration//GEN-END:variables
}
