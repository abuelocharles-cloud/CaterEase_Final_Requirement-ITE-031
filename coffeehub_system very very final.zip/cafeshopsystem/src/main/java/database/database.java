package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * One place for the database connection.
 * Every form calls database.getConnection() when it needs the database.
 * If your MySQL password is not empty (XAMPP default is empty), change PASSWORD.
 * connectionTimeZone=LOCAL: dates and times follow this computer's time zone
 * (Cafeshopsystem.main sets it to Philippine time, Asia/Manila).
 */
public class database {

    private static final String URL = "jdbc:mysql://localhost:3306/coffee_shop"
            + "?useSSL=false&allowPublicKeyRetrieval=true&connectionTimeZone=LOCAL";
    private static final String USER = "root";
    private static final String PASSWORD = "";

    private database() { }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
