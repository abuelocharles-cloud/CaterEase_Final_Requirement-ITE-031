package com.mycompany.cafeshopsystem;

import java.awt.EventQueue;
import view.Theme;
import view.mainframe;

/** Program entry point: applies the coffee theme, then opens the welcome screen. */
public class Cafeshopsystem {

    public static void main(String[] args) {
        // Always use Philippine time (UTC+8), even if the computer's time zone setting is wrong.
        java.util.TimeZone.setDefault(java.util.TimeZone.getTimeZone("Asia/Manila"));
        Theme.install();
        EventQueue.invokeLater(() -> new mainframe().setVisible(true));
    }
}
