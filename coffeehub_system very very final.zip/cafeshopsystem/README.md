# COFFEE HUB SYSTEM (NetBeans JFrame Forms)

## Setup
1. Start **Apache** and **MySQL** in XAMPP.
2. phpMyAdmin -> **Import** -> `database/coffee_shop.sql` -> **Go**
   (creates the `coffee_shop` database, the 5 tables and sample data; replaces those 5 tables if they exist).
3. NetBeans -> **File > Open Project** -> select this `cafeshopsystem` folder.
   First time only: stay online so Maven can download the MySQL driver.
4. If your MySQL root user has a password, edit `PASSWORD` in `src/main/java/database/database.java`.
5. Right-click the project -> **Run** (F6). Main class: `com.mycompany.cafeshopsystem.Cafeshopsystem`.

Admin login: **admin / admin123**

### Hidden admin login
The welcome screen shows only **ORDER NOW** and **EXIT**, so customers never see an admin button.
Staff open the admin login with **Ctrl + Shift + A**, or by **double-clicking the "COFFEE HUB SYSTEM" title**.
The admin login locks for 30 seconds after 3 wrong passwords.
Hiding the door is not security by itself - the password is what protects the admin side.

**Change the admin password** (phpMyAdmin -> `coffee_shop` -> SQL tab):
`UPDATE admins SET password = SHA2('YourNewStrongPassword', 256) WHERE username = 'admin';`

## Editing the screens in the NetBeans Design tab
Every window is a real JFrame Form (`.java` + `.form`) in `src/main/java/view`.
Open any of them and click **Design**: drag components, change text/colors/fonts in the Properties
window, double-click a button to edit its code. Buttons and cards use the rounded classes
`RoundButton` / `RoundPanel` (set through "Custom Creation Code"); in the Design tab they look like
normal buttons, and become rounded when the program runs. Their COLOR is simply the component's
**background** property.

| Form | Screen |
|---|---|
| mainframe | Welcome (Order Now / Exit + hidden admin entrance) |
| AdminLogin | Admin login |
| AdminDashboard | Sidebar + 4 cards + recent orders |
| ManageProducts / ManageCategories | CRUD |
| Sales | Orders list, view items, cancel order |
| SalesReport | Sales per day + top products |
| CustomerDashboard, Cart, Checkout, Receipt | Customer side |

Optional background photo: `src/main/resources/images/background.jpg`.

## Order numbers
MySQL never reuses numbers by itself. Cancelling the newest order in the Sales window frees its number.
To wipe all test orders and restart at Order #1 (for example before your defense), run `database/reset_sales_data.sql` in phpMyAdmin.

## Date and time
The program always uses Philippine time (Asia/Manila, UTC+8), and each order's time is stamped by the program,
not by the MySQL server. If an old test order still shows a wrong time, run `database/reset_sales_data.sql`.
The computer's own clock must be correct.
