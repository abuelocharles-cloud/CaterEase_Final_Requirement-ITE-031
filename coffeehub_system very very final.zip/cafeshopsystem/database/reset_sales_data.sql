-- COFFEE HUB SYSTEM - clear all test orders so Order # starts again at 1.
-- Run in phpMyAdmin: select the coffee_shop database -> SQL tab -> paste -> Go.
-- This deletes ALL orders and order items (products and categories are not touched).
-- It does NOT put stock back; edit stock in Manage Products if needed.

USE coffee_shop;
DELETE FROM orders;                           -- order_items are deleted automatically
ALTER TABLE orders AUTO_INCREMENT = 1;
ALTER TABLE order_items AUTO_INCREMENT = 1;
