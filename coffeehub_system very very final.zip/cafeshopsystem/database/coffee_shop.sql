-- =====================================================================
--  COFFEE HUB SYSTEM
--  Database script for MySQL / phpMyAdmin (XAMPP)
--
--  HOW TO USE: phpMyAdmin -> Import tab -> choose this file -> Go.
--  WARNING: this script DROPS and recreates the 5 tables, so any
--  existing data in them is replaced by the sample data below.
--
--  Default admin account:  username = admin   password = admin123
-- =====================================================================

CREATE DATABASE IF NOT EXISTS coffee_shop
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE coffee_shop;

DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS admins;

-- ---------------------------------------------------------------------
CREATE TABLE admins (
    id        INT AUTO_INCREMENT PRIMARY KEY,
    username  VARCHAR(50)  NOT NULL UNIQUE,
    password  CHAR(64)     NOT NULL,          -- SHA-256 hash, never plain text
    full_name VARCHAR(100) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE categories (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(60)  NOT NULL UNIQUE,
    description VARCHAR(255) NULL
) ENGINE=InnoDB;

CREATE TABLE products (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100)   NOT NULL,
    category_id INT            NOT NULL,
    price       DECIMAL(10,2)  NOT NULL,
    stock       INT            NOT NULL DEFAULT 0,
    -- a category that still has products cannot be deleted
    FOREIGN KEY (category_id) REFERENCES categories(id)
        ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE orders (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    order_date    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    customer_name VARCHAR(100)  NOT NULL DEFAULT 'Walk-in',
    total_amount  DECIMAL(10,2) NOT NULL,
    cash_amount   DECIMAL(10,2) NOT NULL,
    change_amount DECIMAL(10,2) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE order_items (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    order_id     INT           NOT NULL,
    product_id   INT           NULL,           -- becomes NULL if the product is deleted later
    product_name VARCHAR(100)  NOT NULL,       -- copied so old receipts still show the name
    price        DECIMAL(10,2) NOT NULL,
    quantity     INT           NOT NULL,
    subtotal     DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (order_id)   REFERENCES orders(id)   ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
--  SAMPLE DATA
-- ---------------------------------------------------------------------
INSERT INTO admins (username, password, full_name)
VALUES ('admin', SHA2('admin123', 256), 'Administrator');

INSERT INTO categories (name, description) VALUES
 ('Coffee',     'Hot and iced espresso-based drinks'),
 ('Non-Coffee', 'Tea, chocolate and other drinks'),
 ('Pastries',   'Freshly baked goods'),
 ('Desserts',   'Cakes and sweet treats');

INSERT INTO products (name, category_id, price, stock) VALUES
 ('Espresso',           1,  80.00, 50),
 ('Americano',          1,  95.00, 50),
 ('Cappuccino',         1, 120.00, 40),
 ('Caffe Latte',        1, 125.00, 40),
 ('Caramel Macchiato',  1, 145.00, 35),
 ('Hot Chocolate',      2, 110.00, 30),
 ('Matcha Latte',       2, 135.00, 30),
 ('Iced Lemon Tea',     2,  85.00, 45),
 ('Butter Croissant',   3,  75.00, 25),
 ('Blueberry Muffin',   3,  70.00, 25),
 ('Chocolate Cake',     4, 130.00, 20),
 ('Cheesecake Slice',   4, 150.00, 20);
